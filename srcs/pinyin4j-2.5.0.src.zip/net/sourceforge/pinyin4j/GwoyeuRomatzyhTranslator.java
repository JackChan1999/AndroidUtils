package net.sourceforge.pinyin4j;

import com.hp.hpl.sparta.Document;
import com.hp.hpl.sparta.Element;
import com.hp.hpl.sparta.ParseException;

class GwoyeuRomatzyhTranslator
{
  private static String[] tones = { "_I", "_II", "_III", "_IV", "_V" };

  static String convertHanyuPinyinToGwoyeuRomatzyh(String paramString)
  {
    String str1 = TextHelper.extractPinyinString(paramString);
    String str2 = TextHelper.extractToneNumber(paramString);
    Object localObject = null;
    try
    {
      String str3 = "//" + PinyinRomanizationType.HANYU_PINYIN.getTagName() + "[text()='" + str1 + "']";
      Document localDocument = GwoyeuRomatzyhResource.getInstance().getPinyinToGwoyeuMappingDoc();
      Element localElement = localDocument.xpathSelectElement(str3);
      if (null != localElement)
      {
        String str4 = "../" + PinyinRomanizationType.GWOYEU_ROMATZYH.getTagName() + tones[(java.lang.Integer.parseInt(str2) - 1)] + "/text()";
        String str5 = localElement.xpathSelectString(str4);
        localObject = str5;
      }
    }
    catch (ParseException localParseException)
    {
      localParseException.printStackTrace();
    }
    return localObject;
  }
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     net.sourceforge.pinyin4j.GwoyeuRomatzyhTranslator
 * JD-Core Version:    0.6.0
 */