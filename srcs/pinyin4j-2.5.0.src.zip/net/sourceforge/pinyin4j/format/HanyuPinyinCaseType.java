package net.sourceforge.pinyin4j.format;

public class HanyuPinyinCaseType
{
  public static final HanyuPinyinCaseType UPPERCASE = new HanyuPinyinCaseType("UPPERCASE");
  public static final HanyuPinyinCaseType LOWERCASE = new HanyuPinyinCaseType("LOWERCASE");
  protected String name;

  public String getName()
  {
    return this.name;
  }

  protected void setName(String paramString)
  {
    this.name = paramString;
  }

  protected HanyuPinyinCaseType(String paramString)
  {
    setName(paramString);
  }
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     net.sourceforge.pinyin4j.format.HanyuPinyinCaseType
 * JD-Core Version:    0.6.0
 */