package net.sourceforge.pinyin4j.format.exception;

public class BadHanyuPinyinOutputFormatCombination extends Exception
{
  private static final long serialVersionUID = -8500822088036526862L;

  public BadHanyuPinyinOutputFormatCombination(String paramString)
  {
    super(paramString);
  }
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     net.sourceforge.pinyin4j.format.exception.BadHanyuPinyinOutputFormatCombination
 * JD-Core Version:    0.6.0
 */