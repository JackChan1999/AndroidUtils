package net.sourceforge.pinyin4j.format;

public class HanyuPinyinVCharType
{
  public static final HanyuPinyinVCharType WITH_U_AND_COLON = new HanyuPinyinVCharType("WITH_U_AND_COLON");
  public static final HanyuPinyinVCharType WITH_V = new HanyuPinyinVCharType("WITH_V");
  public static final HanyuPinyinVCharType WITH_U_UNICODE = new HanyuPinyinVCharType("WITH_U_UNICODE");
  protected String name;

  public String getName()
  {
    return this.name;
  }

  protected void setName(String paramString)
  {
    this.name = paramString;
  }

  protected HanyuPinyinVCharType(String paramString)
  {
    setName(paramString);
  }
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     net.sourceforge.pinyin4j.format.HanyuPinyinVCharType
 * JD-Core Version:    0.6.0
 */