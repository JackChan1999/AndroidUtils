package net.sourceforge.pinyin4j.format;

public final class HanyuPinyinOutputFormat
{
  private HanyuPinyinVCharType vCharType;
  private HanyuPinyinCaseType caseType;
  private HanyuPinyinToneType toneType;

  public HanyuPinyinOutputFormat()
  {
    restoreDefault();
  }

  public void restoreDefault()
  {
    this.vCharType = HanyuPinyinVCharType.WITH_U_AND_COLON;
    this.caseType = HanyuPinyinCaseType.LOWERCASE;
    this.toneType = HanyuPinyinToneType.WITH_TONE_NUMBER;
  }

  public HanyuPinyinCaseType getCaseType()
  {
    return this.caseType;
  }

  public void setCaseType(HanyuPinyinCaseType paramHanyuPinyinCaseType)
  {
    this.caseType = paramHanyuPinyinCaseType;
  }

  public HanyuPinyinToneType getToneType()
  {
    return this.toneType;
  }

  public void setToneType(HanyuPinyinToneType paramHanyuPinyinToneType)
  {
    this.toneType = paramHanyuPinyinToneType;
  }

  public HanyuPinyinVCharType getVCharType()
  {
    return this.vCharType;
  }

  public void setVCharType(HanyuPinyinVCharType paramHanyuPinyinVCharType)
  {
    this.vCharType = paramHanyuPinyinVCharType;
  }
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     net.sourceforge.pinyin4j.format.HanyuPinyinOutputFormat
 * JD-Core Version:    0.6.0
 */