package net.sourceforge.pinyin4j.format;

public class HanyuPinyinToneType
{
  public static final HanyuPinyinToneType WITH_TONE_NUMBER = new HanyuPinyinToneType("WITH_TONE_NUMBER");
  public static final HanyuPinyinToneType WITHOUT_TONE = new HanyuPinyinToneType("WITHOUT_TONE");
  public static final HanyuPinyinToneType WITH_TONE_MARK = new HanyuPinyinToneType("WITH_TONE_MARK");
  protected String name;

  public String getName()
  {
    return this.name;
  }

  protected void setName(String paramString)
  {
    this.name = paramString;
  }

  protected HanyuPinyinToneType(String paramString)
  {
    setName(paramString);
  }
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     net.sourceforge.pinyin4j.format.HanyuPinyinToneType
 * JD-Core Version:    0.6.0
 */