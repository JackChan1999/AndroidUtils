package net.sourceforge.pinyin4j;

import com.hp.hpl.sparta.Document;
import com.hp.hpl.sparta.ParseException;
import com.hp.hpl.sparta.Parser;
import java.io.FileNotFoundException;
import java.io.IOException;

class PinyinRomanizationResource
{
  private Document pinyinMappingDoc;

  private void setPinyinMappingDoc(Document paramDocument)
  {
    this.pinyinMappingDoc = paramDocument;
  }

  Document getPinyinMappingDoc()
  {
    return this.pinyinMappingDoc;
  }

  private PinyinRomanizationResource()
  {
    initializeResource();
  }

  private void initializeResource()
  {
    try
    {
      setPinyinMappingDoc(Parser.parse("", ResourceHelper.getResourceInputStream("/pinyindb/pinyin_mapping.xml")));
    }
    catch (FileNotFoundException localFileNotFoundException)
    {
      localFileNotFoundException.printStackTrace();
    }
    catch (IOException localIOException)
    {
      localIOException.printStackTrace();
    }
    catch (ParseException localParseException)
    {
      localParseException.printStackTrace();
    }
  }

  static PinyinRomanizationResource getInstance()
  {
    return PinyinRomanizationSystemResourceHolder.theInstance;
  }

  PinyinRomanizationResource(1 param1)
  {
    this();
  }

  private static class PinyinRomanizationSystemResourceHolder
  {
    static final PinyinRomanizationResource theInstance = new PinyinRomanizationResource(null);
  }
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     net.sourceforge.pinyin4j.PinyinRomanizationResource
 * JD-Core Version:    0.6.0
 */