package net.sourceforge.pinyin4j;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

class ChineseToPinyinResource
{
  private Properties unicodeToHanyuPinyinTable = null;

  private void setUnicodeToHanyuPinyinTable(Properties paramProperties)
  {
    this.unicodeToHanyuPinyinTable = paramProperties;
  }

  private Properties getUnicodeToHanyuPinyinTable()
  {
    return this.unicodeToHanyuPinyinTable;
  }

  private ChineseToPinyinResource()
  {
    initializeResource();
  }

  private void initializeResource()
  {
    try
    {
      setUnicodeToHanyuPinyinTable(new Properties());
      getUnicodeToHanyuPinyinTable().load(ResourceHelper.getResourceInputStream("/pinyindb/unicode_to_hanyu_pinyin.txt"));
    }
    catch (FileNotFoundException localFileNotFoundException)
    {
      localFileNotFoundException.printStackTrace();
    }
    catch (IOException localIOException)
    {
      localIOException.printStackTrace();
    }
  }

  String[] getHanyuPinyinStringArray(char paramChar)
  {
    String str1 = getHanyuPinyinRecordFromChar(paramChar);
    if (null != str1)
    {
      int i = str1.indexOf("(");
      int j = str1.lastIndexOf(")");
      String str2 = str1.substring(i + "(".length(), j);
      return str2.split(",");
    }
    return null;
  }

  private boolean isValidRecord(String paramString)
  {
    return (null != paramString) && (!paramString.equals("(none0)")) && (paramString.startsWith("(")) && (paramString.endsWith(")"));
  }

  private String getHanyuPinyinRecordFromChar(char paramChar)
  {
    int i = paramChar;
    String str1 = Integer.toHexString(i).toUpperCase();
    String str2 = getUnicodeToHanyuPinyinTable().getProperty(str1);
    return isValidRecord(str2) ? str2 : null;
  }

  static ChineseToPinyinResource getInstance()
  {
    return ChineseToPinyinResourceHolder.theInstance;
  }

  ChineseToPinyinResource(1 param1)
  {
    this();
  }

  class Field
  {
    static final String LEFT_BRACKET = "(";
    static final String RIGHT_BRACKET = ")";
    static final String COMMA = ",";

    Field()
    {
    }
  }

  private static class ChineseToPinyinResourceHolder
  {
    static final ChineseToPinyinResource theInstance = new ChineseToPinyinResource(null);
  }
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     net.sourceforge.pinyin4j.ChineseToPinyinResource
 * JD-Core Version:    0.6.0
 */