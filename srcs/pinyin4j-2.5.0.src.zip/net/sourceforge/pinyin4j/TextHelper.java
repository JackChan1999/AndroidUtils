package net.sourceforge.pinyin4j;

class TextHelper
{
  static String extractToneNumber(String paramString)
  {
    return paramString.substring(paramString.length() - 1);
  }

  static String extractPinyinString(String paramString)
  {
    return paramString.substring(0, paramString.length() - 1);
  }
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     net.sourceforge.pinyin4j.TextHelper
 * JD-Core Version:    0.6.0
 */