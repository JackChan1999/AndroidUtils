package net.sourceforge.pinyin4j;

import java.io.BufferedInputStream;

class ResourceHelper
{
  static BufferedInputStream getResourceInputStream(String paramString)
  {
    return new BufferedInputStream(ResourceHelper.class.getResourceAsStream(paramString));
  }
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     net.sourceforge.pinyin4j.ResourceHelper
 * JD-Core Version:    0.6.0
 */