package net.sourceforge.pinyin4j;

import com.hp.hpl.sparta.Document;
import com.hp.hpl.sparta.ParseException;
import com.hp.hpl.sparta.Parser;
import java.io.FileNotFoundException;
import java.io.IOException;

class GwoyeuRomatzyhResource
{
  private Document pinyinToGwoyeuMappingDoc;

  private void setPinyinToGwoyeuMappingDoc(Document paramDocument)
  {
    this.pinyinToGwoyeuMappingDoc = paramDocument;
  }

  Document getPinyinToGwoyeuMappingDoc()
  {
    return this.pinyinToGwoyeuMappingDoc;
  }

  private GwoyeuRomatzyhResource()
  {
    initializeResource();
  }

  private void initializeResource()
  {
    try
    {
      setPinyinToGwoyeuMappingDoc(Parser.parse("", ResourceHelper.getResourceInputStream("/pinyindb/pinyin_gwoyeu_mapping.xml")));
    }
    catch (FileNotFoundException localFileNotFoundException)
    {
      localFileNotFoundException.printStackTrace();
    }
    catch (IOException localIOException)
    {
      localIOException.printStackTrace();
    }
    catch (ParseException localParseException)
    {
      localParseException.printStackTrace();
    }
  }

  static GwoyeuRomatzyhResource getInstance()
  {
    return GwoyeuRomatzyhSystemResourceHolder.theInstance;
  }

  GwoyeuRomatzyhResource(1 param1)
  {
    this();
  }

  private static class GwoyeuRomatzyhSystemResourceHolder
  {
    static final GwoyeuRomatzyhResource theInstance = new GwoyeuRomatzyhResource(null);
  }
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     net.sourceforge.pinyin4j.GwoyeuRomatzyhResource
 * JD-Core Version:    0.6.0
 */