package net.sourceforge.pinyin4j;

import net.sourceforge.pinyin4j.format.HanyuPinyinCaseType;
import net.sourceforge.pinyin4j.format.HanyuPinyinOutputFormat;
import net.sourceforge.pinyin4j.format.HanyuPinyinToneType;
import net.sourceforge.pinyin4j.format.HanyuPinyinVCharType;
import net.sourceforge.pinyin4j.format.exception.BadHanyuPinyinOutputFormatCombination;

class PinyinFormatter
{
  static String formatHanyuPinyin(String paramString, HanyuPinyinOutputFormat paramHanyuPinyinOutputFormat)
    throws BadHanyuPinyinOutputFormatCombination
  {
    if ((HanyuPinyinToneType.WITH_TONE_MARK == paramHanyuPinyinOutputFormat.getToneType()) && ((HanyuPinyinVCharType.WITH_V == paramHanyuPinyinOutputFormat.getVCharType()) || (HanyuPinyinVCharType.WITH_U_AND_COLON == paramHanyuPinyinOutputFormat.getVCharType())))
      throw new BadHanyuPinyinOutputFormatCombination("tone marks cannot be added to v or u:");
    if (HanyuPinyinToneType.WITHOUT_TONE == paramHanyuPinyinOutputFormat.getToneType())
    {
      paramString = paramString.replaceAll("[1-5]", "");
    }
    else if (HanyuPinyinToneType.WITH_TONE_MARK == paramHanyuPinyinOutputFormat.getToneType())
    {
      paramString = paramString.replaceAll("u:", "v");
      paramString = convertToneNumber2ToneMark(paramString);
    }
    if (HanyuPinyinVCharType.WITH_V == paramHanyuPinyinOutputFormat.getVCharType())
      paramString = paramString.replaceAll("u:", "v");
    else if (HanyuPinyinVCharType.WITH_U_UNICODE == paramHanyuPinyinOutputFormat.getVCharType())
      paramString = paramString.replaceAll("u:", "ü");
    if (HanyuPinyinCaseType.UPPERCASE == paramHanyuPinyinOutputFormat.getCaseType())
      paramString = paramString.toUpperCase();
    return paramString;
  }

  private static String convertToneNumber2ToneMark(String paramString)
  {
    String str = paramString.toLowerCase();
    if (str.matches("[a-z]*[1-5]?"))
    {
      int i = 36;
      int j = -1;
      if (str.matches("[a-z]*[1-5]"))
      {
        int k = Character.getNumericValue(str.charAt(str.length() - 1));
        int m = str.indexOf('a');
        int n = str.indexOf('e');
        int i1 = str.indexOf("ou");
        int i2;
        if (-1 != m)
        {
          j = m;
          i = 97;
        }
        else if (-1 != n)
        {
          j = n;
          i = 101;
        }
        else if (-1 != i1)
        {
          j = i1;
          i = "ou".charAt(0);
        }
        else
        {
          for (i2 = str.length() - 1; i2 >= 0; i2--)
          {
            if (!String.valueOf(str.charAt(i2)).matches("[aeiouv]"))
              continue;
            j = i2;
            i = str.charAt(i2);
            break;
          }
        }
        if ((36 != i) && (-1 != j))
        {
          i2 = "aeiouv".indexOf(i);
          int i3 = k - 1;
          int i4 = i2 * 5 + i3;
          char c = "āáăàaēéĕèeīíĭìiōóŏòoūúŭùuǖǘǚǜü".charAt(i4);
          StringBuffer localStringBuffer = new StringBuffer();
          localStringBuffer.append(str.substring(0, j).replaceAll("v", "ü"));
          localStringBuffer.append(c);
          localStringBuffer.append(str.substring(j + 1, str.length() - 1).replaceAll("v", "ü"));
          return localStringBuffer.toString();
        }
        return str;
      }
      return str.replaceAll("v", "ü");
    }
    return str;
  }
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     net.sourceforge.pinyin4j.PinyinFormatter
 * JD-Core Version:    0.6.0
 */