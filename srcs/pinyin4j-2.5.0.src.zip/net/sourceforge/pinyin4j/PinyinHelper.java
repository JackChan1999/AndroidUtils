package net.sourceforge.pinyin4j;

import net.sourceforge.pinyin4j.format.HanyuPinyinOutputFormat;
import net.sourceforge.pinyin4j.format.exception.BadHanyuPinyinOutputFormatCombination;

public class PinyinHelper
{
  public static String[] toHanyuPinyinStringArray(char paramChar)
  {
    return getUnformattedHanyuPinyinStringArray(paramChar);
  }

  public static String[] toHanyuPinyinStringArray(char paramChar, HanyuPinyinOutputFormat paramHanyuPinyinOutputFormat)
    throws BadHanyuPinyinOutputFormatCombination
  {
    return getFormattedHanyuPinyinStringArray(paramChar, paramHanyuPinyinOutputFormat);
  }

  private static String[] getFormattedHanyuPinyinStringArray(char paramChar, HanyuPinyinOutputFormat paramHanyuPinyinOutputFormat)
    throws BadHanyuPinyinOutputFormatCombination
  {
    String[] arrayOfString = getUnformattedHanyuPinyinStringArray(paramChar);
    if (null != arrayOfString)
    {
      for (int i = 0; i < arrayOfString.length; i++)
        arrayOfString[i] = PinyinFormatter.formatHanyuPinyin(arrayOfString[i], paramHanyuPinyinOutputFormat);
      return arrayOfString;
    }
    return null;
  }

  private static String[] getUnformattedHanyuPinyinStringArray(char paramChar)
  {
    return ChineseToPinyinResource.getInstance().getHanyuPinyinStringArray(paramChar);
  }

  public static String[] toTongyongPinyinStringArray(char paramChar)
  {
    return convertToTargetPinyinStringArray(paramChar, PinyinRomanizationType.TONGYONG_PINYIN);
  }

  public static String[] toWadeGilesPinyinStringArray(char paramChar)
  {
    return convertToTargetPinyinStringArray(paramChar, PinyinRomanizationType.WADEGILES_PINYIN);
  }

  public static String[] toMPS2PinyinStringArray(char paramChar)
  {
    return convertToTargetPinyinStringArray(paramChar, PinyinRomanizationType.MPS2_PINYIN);
  }

  public static String[] toYalePinyinStringArray(char paramChar)
  {
    return convertToTargetPinyinStringArray(paramChar, PinyinRomanizationType.YALE_PINYIN);
  }

  private static String[] convertToTargetPinyinStringArray(char paramChar, PinyinRomanizationType paramPinyinRomanizationType)
  {
    String[] arrayOfString1 = getUnformattedHanyuPinyinStringArray(paramChar);
    if (null != arrayOfString1)
    {
      String[] arrayOfString2 = new String[arrayOfString1.length];
      for (int i = 0; i < arrayOfString1.length; i++)
        arrayOfString2[i] = PinyinRomanizationTranslator.convertRomanizationSystem(arrayOfString1[i], PinyinRomanizationType.HANYU_PINYIN, paramPinyinRomanizationType);
      return arrayOfString2;
    }
    return null;
  }

  public static String[] toGwoyeuRomatzyhStringArray(char paramChar)
  {
    return convertToGwoyeuRomatzyhStringArray(paramChar);
  }

  private static String[] convertToGwoyeuRomatzyhStringArray(char paramChar)
  {
    String[] arrayOfString1 = getUnformattedHanyuPinyinStringArray(paramChar);
    if (null != arrayOfString1)
    {
      String[] arrayOfString2 = new String[arrayOfString1.length];
      for (int i = 0; i < arrayOfString1.length; i++)
        arrayOfString2[i] = GwoyeuRomatzyhTranslator.convertHanyuPinyinToGwoyeuRomatzyh(arrayOfString1[i]);
      return arrayOfString2;
    }
    return null;
  }

  /** @deprecated */
  public static String toHanyuPinyinString(String paramString1, HanyuPinyinOutputFormat paramHanyuPinyinOutputFormat, String paramString2)
    throws BadHanyuPinyinOutputFormatCombination
  {
    StringBuffer localStringBuffer = new StringBuffer();
    for (int i = 0; i < paramString1.length(); i++)
    {
      String str = getFirstHanyuPinyinString(paramString1.charAt(i), paramHanyuPinyinOutputFormat);
      if (null != str)
      {
        localStringBuffer.append(str);
        if (i == paramString1.length() - 1)
          continue;
        localStringBuffer.append(paramString2);
      }
      else
      {
        localStringBuffer.append(paramString1.charAt(i));
      }
    }
    return localStringBuffer.toString();
  }

  /** @deprecated */
  private static String getFirstHanyuPinyinString(char paramChar, HanyuPinyinOutputFormat paramHanyuPinyinOutputFormat)
    throws BadHanyuPinyinOutputFormatCombination
  {
    String[] arrayOfString = getFormattedHanyuPinyinStringArray(paramChar, paramHanyuPinyinOutputFormat);
    if ((null != arrayOfString) && (arrayOfString.length > 0))
      return arrayOfString[0];
    return null;
  }
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     net.sourceforge.pinyin4j.PinyinHelper
 * JD-Core Version:    0.6.0
 */