package net.sourceforge.pinyin4j;

class PinyinRomanizationType
{
  static final PinyinRomanizationType HANYU_PINYIN = new PinyinRomanizationType("Hanyu");
  static final PinyinRomanizationType WADEGILES_PINYIN = new PinyinRomanizationType("Wade");
  static final PinyinRomanizationType MPS2_PINYIN = new PinyinRomanizationType("MPSII");
  static final PinyinRomanizationType YALE_PINYIN = new PinyinRomanizationType("Yale");
  static final PinyinRomanizationType TONGYONG_PINYIN = new PinyinRomanizationType("Tongyong");
  static final PinyinRomanizationType GWOYEU_ROMATZYH = new PinyinRomanizationType("Gwoyeu");
  protected String tagName;

  protected PinyinRomanizationType(String paramString)
  {
    setTagName(paramString);
  }

  String getTagName()
  {
    return this.tagName;
  }

  protected void setTagName(String paramString)
  {
    this.tagName = paramString;
  }
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     net.sourceforge.pinyin4j.PinyinRomanizationType
 * JD-Core Version:    0.6.0
 */