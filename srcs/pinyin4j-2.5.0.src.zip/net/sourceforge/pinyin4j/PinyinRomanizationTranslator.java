package net.sourceforge.pinyin4j;

import com.hp.hpl.sparta.Document;
import com.hp.hpl.sparta.Element;
import com.hp.hpl.sparta.ParseException;

class PinyinRomanizationTranslator
{
  static String convertRomanizationSystem(String paramString, PinyinRomanizationType paramPinyinRomanizationType1, PinyinRomanizationType paramPinyinRomanizationType2)
  {
    String str1 = TextHelper.extractPinyinString(paramString);
    String str2 = TextHelper.extractToneNumber(paramString);
    String str3 = null;
    try
    {
      String str4 = "//" + paramPinyinRomanizationType1.getTagName() + "[text()='" + str1 + "']";
      Document localDocument = PinyinRomanizationResource.getInstance().getPinyinMappingDoc();
      Element localElement = localDocument.xpathSelectElement(str4);
      if (null != localElement)
      {
        String str5 = "../" + paramPinyinRomanizationType2.getTagName() + "/text()";
        String str6 = localElement.xpathSelectString(str5);
        str3 = str6 + str2;
      }
    }
    catch (ParseException localParseException)
    {
      localParseException.printStackTrace();
    }
    return str3;
  }
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     net.sourceforge.pinyin4j.PinyinRomanizationTranslator
 * JD-Core Version:    0.6.0
 */