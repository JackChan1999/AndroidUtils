package com.hp.hpl.sparta;

import java.util.Hashtable;

public class Sparta
{
  private static Internment internment_ = new Internment()
  {
    private final Hashtable strings_ = new Hashtable();

    public String intern(String paramString)
    {
      String str = (String)this.strings_.get(paramString);
      if (str == null)
      {
        this.strings_.put(paramString, paramString);
        return paramString;
      }
      return str;
    }
  };
  private static CacheFactory cacheFactory_ = new CacheFactory()
  {
    public Sparta.Cache create()
    {
      return new Sparta.HashtableCache(null);
    }
  };

  public static String intern(String paramString)
  {
    return internment_.intern(paramString);
  }

  public static void setInternment(Internment paramInternment)
  {
    internment_ = paramInternment;
  }

  static Cache newCache()
  {
    return cacheFactory_.create();
  }

  public static void setCacheFactory(CacheFactory paramCacheFactory)
  {
    cacheFactory_ = paramCacheFactory;
  }

  private static class HashtableCache extends Hashtable
    implements Sparta.Cache
  {
    private HashtableCache()
    {
    }

    HashtableCache(Sparta.1 param1)
    {
      this();
    }
  }

  public static abstract interface CacheFactory
  {
    public abstract Sparta.Cache create();
  }

  public static abstract interface Cache
  {
    public abstract Object get(Object paramObject);

    public abstract Object put(Object paramObject1, Object paramObject2);

    public abstract int size();
  }

  public static abstract interface Internment
  {
    public abstract String intern(String paramString);
  }
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     com.hp.hpl.sparta.Sparta
 * JD-Core Version:    0.6.0
 */