package com.hp.hpl.sparta;

import java.io.IOException;
import java.io.Reader;
import java.util.Hashtable;

class ParseCharStream
  implements ParseSource
{
  private static final boolean DEBUG = true;
  private static final boolean H_DEBUG = false;
  private static final char[] NAME_PUNCT_CHARS = { '.', '-', '_', ':' };
  private static final int MAX_COMMON_CHAR = 128;
  private static final boolean[] IS_NAME_CHAR = new boolean[''];
  private static final char[] COMMENT_BEGIN;
  private static final char[] COMMENT_END;
  private static final char[] PI_BEGIN;
  private static final char[] QU_END;
  private static final char[] DOCTYPE_BEGIN;
  private static final char[] XML_BEGIN;
  private static final char[] ENCODING;
  private static final char[] VERSION;
  private static final char[] VERSIONNUM_PUNC_CHARS;
  private static final char[] MARKUPDECL_BEGIN;
  private static final char[] CHARREF_BEGIN;
  private static final char[] ENTITY_BEGIN;
  private static final char[] NDATA;
  private static final char[] SYSTEM;
  private static final char[] PUBLIC;
  private static final char[] BEGIN_CDATA;
  private static final char[] END_CDATA;
  private static final char[] END_EMPTYTAG;
  private static final char[] BEGIN_ETAG;
  private String systemId_;
  private String docTypeName_ = null;
  private final Reader reader_;
  private final Hashtable entities_ = new Hashtable();
  private final Hashtable pes_ = new Hashtable();
  private final ParseLog log_;
  private final String encoding_;
  private int ch_ = -2;
  private boolean isExternalDtd_ = false;
  private final int CBUF_SIZE = 1024;
  private final char[] cbuf_;
  private int curPos_ = 0;
  private int endPos_ = 0;
  private boolean eos_ = false;
  private static final int TMP_BUF_SIZE = 255;
  private final char[] tmpBuf_ = new char['ÿ'];
  private int lineNumber_ = -1;
  private final CharCircBuffer history_ = null;
  public static final int HISTORY_LENGTH = 100;
  private final ParseHandler handler_;

  public ParseCharStream(String paramString1, char[] paramArrayOfChar, ParseLog paramParseLog, String paramString2, ParseHandler paramParseHandler)
    throws ParseException, EncodingMismatchException, IOException
  {
    this(paramString1, null, paramArrayOfChar, paramParseLog, paramString2, paramParseHandler);
  }

  public ParseCharStream(String paramString1, Reader paramReader, ParseLog paramParseLog, String paramString2, ParseHandler paramParseHandler)
    throws ParseException, EncodingMismatchException, IOException
  {
    this(paramString1, paramReader, null, paramParseLog, paramString2, paramParseHandler);
  }

  public ParseCharStream(String paramString1, Reader paramReader, char[] paramArrayOfChar, ParseLog paramParseLog, String paramString2, ParseHandler paramParseHandler)
    throws ParseException, EncodingMismatchException, IOException
  {
    this.log_ = (paramParseLog == null ? ParseSource.DEFAULT_LOG : paramParseLog);
    this.encoding_ = (paramString2 == null ? null : paramString2.toLowerCase());
    this.entities_.put("lt", "<");
    this.entities_.put("gt", ">");
    this.entities_.put("amp", "&");
    this.entities_.put("apos", "'");
    this.entities_.put("quot", "\"");
    if (paramArrayOfChar != null)
    {
      this.cbuf_ = paramArrayOfChar;
      this.curPos_ = 0;
      this.endPos_ = this.cbuf_.length;
      this.eos_ = true;
      this.reader_ = null;
    }
    else
    {
      this.reader_ = paramReader;
      this.cbuf_ = new char[1024];
      fillBuf();
    }
    this.systemId_ = paramString1;
    this.handler_ = paramParseHandler;
    this.handler_.setParseSource(this);
    readProlog();
    this.handler_.startDocument();
    Element localElement = readElement();
    if ((this.docTypeName_ != null) && (!this.docTypeName_.equals(localElement.getTagName())))
      this.log_.warning("DOCTYPE name \"" + this.docTypeName_ + "\" not same as tag name, \"" + localElement.getTagName() + "\" of root element", this.systemId_, getLineNumber());
    while (isMisc())
      readMisc();
    if (this.reader_ != null)
      this.reader_.close();
    this.handler_.endDocument();
  }

  public String toString()
  {
    return this.systemId_;
  }

  public String getSystemId()
  {
    return this.systemId_;
  }

  public int getLineNumber()
  {
    return this.lineNumber_;
  }

  int getLastCharRead()
  {
    return this.ch_;
  }

  final String getHistory()
  {
    return "";
  }

  private int fillBuf()
    throws IOException
  {
    if (this.eos_)
      return -1;
    if (this.endPos_ == this.cbuf_.length)
      this.curPos_ = (this.endPos_ = 0);
    int i = this.reader_.read(this.cbuf_, this.endPos_, this.cbuf_.length - this.endPos_);
    if (i <= 0)
    {
      this.eos_ = true;
      return -1;
    }
    this.endPos_ += i;
    return i;
  }

  private int fillBuf(int paramInt)
    throws IOException
  {
    if (this.eos_)
      return -1;
    int i = 0;
    if (this.cbuf_.length - this.curPos_ < paramInt)
    {
      for (j = 0; this.curPos_ + j < this.endPos_; j++)
        this.cbuf_[j] = this.cbuf_[(this.curPos_ + j)];
      i = this.endPos_ - this.curPos_;
      this.endPos_ = i;
      this.curPos_ = 0;
    }
    int j = fillBuf();
    if (j == -1)
    {
      if (i == 0)
        return -1;
      return i;
    }
    return i + j;
  }

  private final char readChar()
    throws ParseException, IOException
  {
    if ((this.curPos_ >= this.endPos_) && (fillBuf() == -1))
      throw new ParseException(this, "unexpected end of expression.");
    if (this.cbuf_[this.curPos_] == '\n')
      this.lineNumber_ += 1;
    return this.cbuf_[(this.curPos_++)];
  }

  private final char peekChar()
    throws ParseException, IOException
  {
    if ((this.curPos_ >= this.endPos_) && (fillBuf() == -1))
      throw new ParseException(this, "unexpected end of expression.");
    return this.cbuf_[this.curPos_];
  }

  private final void readChar(char paramChar)
    throws ParseException, IOException
  {
    char c = readChar();
    if (c != paramChar)
      throw new ParseException(this, c, paramChar);
  }

  private final boolean isChar(char paramChar)
    throws ParseException, IOException
  {
    if ((this.curPos_ >= this.endPos_) && (fillBuf() == -1))
      throw new ParseException(this, "unexpected end of expression.");
    return this.cbuf_[this.curPos_] == paramChar;
  }

  private final char readChar(char paramChar1, char paramChar2)
    throws ParseException, IOException
  {
    char c = readChar();
    if ((c != paramChar1) && (c != paramChar2))
      throw new ParseException(this, c, new char[] { paramChar1, paramChar2 });
    return c;
  }

  private final char readChar(char paramChar1, char paramChar2, char paramChar3, char paramChar4)
    throws ParseException, IOException
  {
    char c = readChar();
    if ((c != paramChar1) && (c != paramChar2) && (c != paramChar3) && (c != paramChar4))
      throw new ParseException(this, c, new char[] { paramChar1, paramChar2, paramChar3, paramChar4 });
    return c;
  }

  private final boolean isChar(char paramChar1, char paramChar2)
    throws ParseException, IOException
  {
    if ((this.curPos_ >= this.endPos_) && (fillBuf() == -1))
      return false;
    char c = this.cbuf_[this.curPos_];
    return (c == paramChar1) || (c == paramChar2);
  }

  private final boolean isChar(char paramChar1, char paramChar2, char paramChar3, char paramChar4)
    throws ParseException, IOException
  {
    if ((this.curPos_ >= this.endPos_) && (fillBuf() == -1))
      return false;
    char c = this.cbuf_[this.curPos_];
    return (c == paramChar1) || (c == paramChar2) || (c == paramChar3) || (c == paramChar4);
  }

  private static final boolean isIn(char paramChar, char[] paramArrayOfChar)
  {
    for (int i = 0; i < paramArrayOfChar.length; i++)
      if (paramChar == paramArrayOfChar[i])
        return true;
    return false;
  }

  private final void readS()
    throws ParseException, IOException
  {
    readChar(' ', '\t', '\r', '\n');
    while (isChar(' ', '\t', '\r', '\n'))
      readChar();
  }

  private final boolean isS()
    throws ParseException, IOException
  {
    return isChar(' ', '\t', '\r', '\n');
  }

  private boolean isNameChar()
    throws ParseException, IOException
  {
    char c = peekChar();
    return c < '' ? IS_NAME_CHAR[c] : isNameChar(c);
  }

  private static boolean isLetter(char paramChar)
  {
    return "abcdefghijklmnopqrstuvwxyz".indexOf(Character.toLowerCase(paramChar)) != -1;
  }

  private static boolean isNameChar(char paramChar)
  {
    return (Character.isDigit(paramChar)) || (isLetter(paramChar)) || (isIn(paramChar, NAME_PUNCT_CHARS)) || (isExtender(paramChar));
  }

  private static boolean isExtender(char paramChar)
  {
    switch (paramChar)
    {
    case '·':
    case 'ː':
    case 'ˑ':
    case '·':
    case 'ـ':
    case 'ๆ':
    case 'ໆ':
    case '々':
    case '〱':
    case '〲':
    case '〳':
    case '〴':
    case '〵':
    case 'ゝ':
    case 'ゞ':
    case 'ー':
    case 'ヽ':
    case 'ヾ':
      return true;
    }
    return false;
  }

  private final String readName()
    throws ParseException, IOException
  {
    StringBuffer localStringBuffer = null;
    int i = 0;
    this.tmpBuf_[(i++)] = readNameStartChar();
    while (isNameChar())
    {
      if (i >= 255)
      {
        if (localStringBuffer == null)
        {
          localStringBuffer = new StringBuffer(i);
          localStringBuffer.append(this.tmpBuf_, 0, i);
        }
        else
        {
          localStringBuffer.append(this.tmpBuf_, 0, i);
        }
        i = 0;
      }
      this.tmpBuf_[(i++)] = readChar();
    }
    if (localStringBuffer == null)
      return Sparta.intern(new String(this.tmpBuf_, 0, i));
    localStringBuffer.append(this.tmpBuf_, 0, i);
    return localStringBuffer.toString();
  }

  private char readNameStartChar()
    throws ParseException, IOException
  {
    char c = readChar();
    if ((!isLetter(c)) && (c != '_') && (c != ':'))
      throw new ParseException(this, c, "letter, underscore, colon");
    return c;
  }

  private final String readEntityValue()
    throws ParseException, IOException
  {
    char c = readChar('\'', '"');
    StringBuffer localStringBuffer = new StringBuffer();
    while (!isChar(c))
      if (isPeReference())
        localStringBuffer.append(readPeReference());
      else if (isReference())
        localStringBuffer.append(readReference());
      else
        localStringBuffer.append(readChar());
    readChar(c);
    return localStringBuffer.toString();
  }

  private final boolean isEntityValue()
    throws ParseException, IOException
  {
    return isChar('\'', '"');
  }

  private final void readSystemLiteral()
    throws ParseException, IOException
  {
    char c = readChar();
    while (peekChar() != c)
      readChar();
    readChar(c);
  }

  private final void readPubidLiteral()
    throws ParseException, IOException
  {
    readSystemLiteral();
  }

  private boolean isMisc()
    throws ParseException, IOException
  {
    return (isComment()) || (isPi()) || (isS());
  }

  private void readMisc()
    throws ParseException, IOException
  {
    if (isComment())
      readComment();
    else if (isPi())
      readPi();
    else if (isS())
      readS();
    else
      throw new ParseException(this, "expecting comment or processing instruction or space");
  }

  private final void readComment()
    throws ParseException, IOException
  {
    readSymbol(COMMENT_BEGIN);
    while (!isSymbol(COMMENT_END))
      readChar();
    readSymbol(COMMENT_END);
  }

  private final boolean isComment()
    throws ParseException, IOException
  {
    return isSymbol(COMMENT_BEGIN);
  }

  private final void readPi()
    throws ParseException, IOException
  {
    readSymbol(PI_BEGIN);
    while (!isSymbol(QU_END))
      readChar();
    readSymbol(QU_END);
  }

  private final boolean isPi()
    throws ParseException, IOException
  {
    return isSymbol(PI_BEGIN);
  }

  private void readProlog()
    throws ParseException, EncodingMismatchException, IOException
  {
    if (isXmlDecl())
      readXmlDecl();
    while (isMisc())
      readMisc();
    if (isDocTypeDecl())
    {
      readDocTypeDecl();
      while (isMisc())
        readMisc();
    }
  }

  private boolean isDocTypeDecl()
    throws ParseException, IOException
  {
    return isSymbol(DOCTYPE_BEGIN);
  }

  private void readXmlDecl()
    throws ParseException, EncodingMismatchException, IOException
  {
    readSymbol(XML_BEGIN);
    readVersionInfo();
    if (isS())
      readS();
    if (isEncodingDecl())
    {
      String str = readEncodingDecl();
      if ((this.encoding_ != null) && (!str.toLowerCase().equals(this.encoding_)))
        throw new EncodingMismatchException(this.systemId_, str, this.encoding_);
    }
    do
      readChar();
    while (!isSymbol(QU_END));
    readSymbol(QU_END);
  }

  private boolean isXmlDecl()
    throws ParseException, IOException
  {
    return isSymbol(XML_BEGIN);
  }

  private boolean isEncodingDecl()
    throws ParseException, IOException
  {
    return isSymbol(ENCODING);
  }

  private String readEncodingDecl()
    throws ParseException, IOException
  {
    readSymbol(ENCODING);
    readEq();
    char c = readChar('\'', '"');
    StringBuffer localStringBuffer = new StringBuffer();
    while (!isChar(c))
      localStringBuffer.append(readChar());
    readChar(c);
    return localStringBuffer.toString();
  }

  private void readVersionInfo()
    throws ParseException, IOException
  {
    readS();
    readSymbol(VERSION);
    readEq();
    char c = readChar('\'', '"');
    readVersionNum();
    readChar(c);
  }

  private final void readEq()
    throws ParseException, IOException
  {
    if (isS())
      readS();
    readChar('=');
    if (isS())
      readS();
  }

  private boolean isVersionNumChar()
    throws ParseException, IOException
  {
    char c = peekChar();
    return (Character.isDigit(c)) || (('a' <= c) && (c <= 'z')) || (('Z' <= c) && (c <= 'Z')) || (isIn(c, VERSIONNUM_PUNC_CHARS));
  }

  private void readVersionNum()
    throws ParseException, IOException
  {
    readChar();
    while (isVersionNumChar())
      readChar();
  }

  private void readDocTypeDecl()
    throws ParseException, IOException
  {
    readSymbol(DOCTYPE_BEGIN);
    readS();
    this.docTypeName_ = readName();
    if (isS())
    {
      readS();
      if ((!isChar('>')) && (!isChar('[')))
      {
        this.isExternalDtd_ = true;
        readExternalId();
        if (isS())
          readS();
      }
    }
    if (isChar('['))
    {
      readChar();
      while (!isChar(']'))
        if (isDeclSep())
          readDeclSep();
        else
          readMarkupDecl();
      readChar(']');
      if (isS())
        readS();
    }
    readChar('>');
  }

  private void readDeclSep()
    throws ParseException, IOException
  {
    if (isPeReference())
      readPeReference();
    else
      readS();
  }

  private boolean isDeclSep()
    throws ParseException, IOException
  {
    return (isPeReference()) || (isS());
  }

  private void readMarkupDecl()
    throws ParseException, IOException
  {
    if (isPi())
    {
      readPi();
    }
    else if (isComment())
    {
      readComment();
    }
    else if (isEntityDecl())
    {
      readEntityDecl();
    }
    else if (isSymbol(MARKUPDECL_BEGIN))
    {
      while (!isChar('>'))
        if (isChar('\'', '"'))
        {
          char c = readChar();
          while (!isChar(c))
            readChar();
          readChar(c);
        }
        else
        {
          readChar();
        }
      readChar('>');
    }
    else
    {
      throw new ParseException(this, "expecting processing instruction, comment, or \"<!\"");
    }
  }

  private char readCharRef()
    throws ParseException, IOException
  {
    readSymbol(CHARREF_BEGIN);
    int i = 10;
    if (isChar('x'))
    {
      readChar();
      i = 16;
    }
    int j = 0;
    while (!isChar(';'))
    {
      this.tmpBuf_[(j++)] = readChar();
      if (j < 255)
        continue;
      this.log_.warning("Tmp buffer overflow on readCharRef", this.systemId_, getLineNumber());
      return ' ';
    }
    readChar(';');
    String str = new String(this.tmpBuf_, 0, j);
    try
    {
      return (char)Integer.parseInt(str, i);
    }
    catch (NumberFormatException localNumberFormatException)
    {
      this.log_.warning("\"" + str + "\" is not a valid " + (i == 16 ? "hexadecimal" : "decimal") + " number", this.systemId_, getLineNumber());
    }
    return ' ';
  }

  private final char[] readReference()
    throws ParseException, IOException
  {
    if (isSymbol(CHARREF_BEGIN))
      return new char[] { readCharRef() };
    return readEntityRef().toCharArray();
  }

  private final boolean isReference()
    throws ParseException, IOException
  {
    return isChar('&');
  }

  private String readEntityRef()
    throws ParseException, IOException
  {
    readChar('&');
    String str1 = readName();
    String str2 = (String)this.entities_.get(str1);
    if (str2 == null)
    {
      str2 = "";
      if (this.isExternalDtd_)
        this.log_.warning("&" + str1 + "; not found -- possibly defined in external DTD)", this.systemId_, getLineNumber());
      else
        this.log_.warning("No declaration of &" + str1 + ";", this.systemId_, getLineNumber());
    }
    readChar(';');
    return str2;
  }

  private String readPeReference()
    throws ParseException, IOException
  {
    readChar('%');
    String str1 = readName();
    String str2 = (String)this.pes_.get(str1);
    if (str2 == null)
    {
      str2 = "";
      this.log_.warning("No declaration of %" + str1 + ";", this.systemId_, getLineNumber());
    }
    readChar(';');
    return str2;
  }

  private boolean isPeReference()
    throws ParseException, IOException
  {
    return isChar('%');
  }

  private void readEntityDecl()
    throws ParseException, IOException
  {
    readSymbol(ENTITY_BEGIN);
    readS();
    String str1;
    String str2;
    if (isChar('%'))
    {
      readChar('%');
      readS();
      str1 = readName();
      readS();
      if (isEntityValue())
        str2 = readEntityValue();
      else
        str2 = readExternalId();
      this.pes_.put(str1, str2);
    }
    else
    {
      str1 = readName();
      readS();
      if (isEntityValue())
      {
        str2 = readEntityValue();
      }
      else if (isExternalId())
      {
        str2 = readExternalId();
        if (isS())
          readS();
        if (isSymbol(NDATA))
        {
          readSymbol(NDATA);
          readS();
          readName();
        }
      }
      else
      {
        throw new ParseException(this, "expecting double-quote, \"PUBLIC\" or \"SYSTEM\" while reading entity declaration");
      }
      this.entities_.put(str1, str2);
    }
    if (isS())
      readS();
    readChar('>');
  }

  private boolean isEntityDecl()
    throws ParseException, IOException
  {
    return isSymbol(ENTITY_BEGIN);
  }

  private String readExternalId()
    throws ParseException, IOException
  {
    if (isSymbol(SYSTEM))
    {
      readSymbol(SYSTEM);
    }
    else if (isSymbol(PUBLIC))
    {
      readSymbol(PUBLIC);
      readS();
      readPubidLiteral();
    }
    else
    {
      throw new ParseException(this, "expecting \"SYSTEM\" or \"PUBLIC\" while reading external ID");
    }
    readS();
    readSystemLiteral();
    return "(WARNING: external ID not read)";
  }

  private boolean isExternalId()
    throws ParseException, IOException
  {
    return (isSymbol(SYSTEM)) || (isSymbol(PUBLIC));
  }

  private final void readSymbol(char[] paramArrayOfChar)
    throws ParseException, IOException
  {
    int i = paramArrayOfChar.length;
    if ((this.endPos_ - this.curPos_ < i) && (fillBuf(i) <= 0))
    {
      this.ch_ = -1;
      throw new ParseException(this, "end of XML file", paramArrayOfChar);
    }
    this.ch_ = this.cbuf_[(this.endPos_ - 1)];
    if (this.endPos_ - this.curPos_ < i)
      throw new ParseException(this, "end of XML file", paramArrayOfChar);
    for (int j = 0; j < i; j++)
    {
      if (this.cbuf_[(this.curPos_ + j)] == paramArrayOfChar[j])
        continue;
      throw new ParseException(this, new String(this.cbuf_, this.curPos_, i), paramArrayOfChar);
    }
    this.curPos_ += i;
  }

  private final boolean isSymbol(char[] paramArrayOfChar)
    throws ParseException, IOException
  {
    int i = paramArrayOfChar.length;
    if ((this.endPos_ - this.curPos_ < i) && (fillBuf(i) <= 0))
    {
      this.ch_ = -1;
      return false;
    }
    this.ch_ = this.cbuf_[(this.endPos_ - 1)];
    if (this.endPos_ - this.curPos_ < i)
      return false;
    for (int j = 0; j < i; j++)
      if (this.cbuf_[(this.curPos_ + j)] != paramArrayOfChar[j])
        return false;
    return true;
  }

  private String readAttValue()
    throws ParseException, IOException
  {
    char c = readChar('\'', '"');
    StringBuffer localStringBuffer = new StringBuffer();
    while (!isChar(c))
      if (isReference())
        localStringBuffer.append(readReference());
      else
        localStringBuffer.append(readChar());
    readChar(c);
    return localStringBuffer.toString();
  }

  private void readPossibleCharData()
    throws ParseException, IOException
  {
    int i = 0;
    while ((!isChar('<')) && (!isChar('&')) && (!isSymbol(END_CDATA)))
    {
      this.tmpBuf_[i] = readChar();
      if ((this.tmpBuf_[i] == '\r') && (peekChar() == '\n'))
        this.tmpBuf_[i] = readChar();
      i++;
      if (i != 255)
        continue;
      this.handler_.characters(this.tmpBuf_, 0, 255);
      i = 0;
    }
    if (i > 0)
      this.handler_.characters(this.tmpBuf_, 0, i);
  }

  private void readCdSect()
    throws ParseException, IOException
  {
    StringBuffer localStringBuffer = null;
    readSymbol(BEGIN_CDATA);
    int i = 0;
    while (!isSymbol(END_CDATA))
    {
      if (i >= 255)
      {
        if (localStringBuffer == null)
        {
          localStringBuffer = new StringBuffer(i);
          localStringBuffer.append(this.tmpBuf_, 0, i);
        }
        else
        {
          localStringBuffer.append(this.tmpBuf_, 0, i);
        }
        i = 0;
      }
      this.tmpBuf_[(i++)] = readChar();
    }
    readSymbol(END_CDATA);
    if (localStringBuffer != null)
    {
      localStringBuffer.append(this.tmpBuf_, 0, i);
      char[] arrayOfChar = localStringBuffer.toString().toCharArray();
      this.handler_.characters(arrayOfChar, 0, arrayOfChar.length);
    }
    else
    {
      this.handler_.characters(this.tmpBuf_, 0, i);
    }
  }

  private boolean isCdSect()
    throws ParseException, IOException
  {
    return isSymbol(BEGIN_CDATA);
  }

  private final Element readElement()
    throws ParseException, IOException
  {
    Element localElement = new Element();
    boolean bool = readEmptyElementTagOrSTag(localElement);
    this.handler_.startElement(localElement);
    if (bool)
    {
      readContent();
      readETag(localElement);
    }
    this.handler_.endElement(localElement);
    return localElement;
  }

  ParseLog getLog()
  {
    return this.log_;
  }

  private boolean readEmptyElementTagOrSTag(Element paramElement)
    throws ParseException, IOException
  {
    readChar('<');
    paramElement.setTagName(readName());
    while (isS())
    {
      readS();
      if (isChar('/', '>'))
        continue;
      readAttribute(paramElement);
    }
    if (isS())
      readS();
    boolean bool = isChar('>');
    if (bool)
      readChar('>');
    else
      readSymbol(END_EMPTYTAG);
    return bool;
  }

  private void readAttribute(Element paramElement)
    throws ParseException, IOException
  {
    String str1 = readName();
    readEq();
    String str2 = readAttValue();
    if (paramElement.getAttribute(str1) != null)
      this.log_.warning("Element " + this + " contains attribute " + str1 + "more than once", this.systemId_, getLineNumber());
    paramElement.setAttribute(str1, str2);
  }

  private void readETag(Element paramElement)
    throws ParseException, IOException
  {
    readSymbol(BEGIN_ETAG);
    String str = readName();
    if (!str.equals(paramElement.getTagName()))
      this.log_.warning("end tag (" + str + ") does not match begin tag (" + paramElement.getTagName() + ")", this.systemId_, getLineNumber());
    if (isS())
      readS();
    readChar('>');
  }

  private boolean isETag()
    throws ParseException, IOException
  {
    return isSymbol(BEGIN_ETAG);
  }

  private void readContent()
    throws ParseException, IOException
  {
    readPossibleCharData();
    int i = 1;
    while (i != 0)
    {
      if (isETag())
      {
        i = 0;
      }
      else if (isReference())
      {
        char[] arrayOfChar = readReference();
        this.handler_.characters(arrayOfChar, 0, arrayOfChar.length);
      }
      else if (isCdSect())
      {
        readCdSect();
      }
      else if (isPi())
      {
        readPi();
      }
      else if (isComment())
      {
        readComment();
      }
      else if (isChar('<'))
      {
        readElement();
      }
      else
      {
        i = 0;
      }
      readPossibleCharData();
    }
  }

  static
  {
    for (char c = '\000'; c < ''; c = (char)(c + '\001'))
      IS_NAME_CHAR[c] = isNameChar(c);
    COMMENT_BEGIN = "<!--".toCharArray();
    COMMENT_END = "-->".toCharArray();
    PI_BEGIN = "<?".toCharArray();
    QU_END = "?>".toCharArray();
    DOCTYPE_BEGIN = "<!DOCTYPE".toCharArray();
    XML_BEGIN = "<?xml".toCharArray();
    ENCODING = "encoding".toCharArray();
    VERSION = "version".toCharArray();
    VERSIONNUM_PUNC_CHARS = new char[] { '_', '.', ':', '-' };
    MARKUPDECL_BEGIN = "<!".toCharArray();
    CHARREF_BEGIN = "&#".toCharArray();
    ENTITY_BEGIN = "<!ENTITY".toCharArray();
    NDATA = "NDATA".toCharArray();
    SYSTEM = "SYSTEM".toCharArray();
    PUBLIC = "PUBLIC".toCharArray();
    BEGIN_CDATA = "<![CDATA[".toCharArray();
    END_CDATA = "]]>".toCharArray();
    END_EMPTYTAG = "/>".toCharArray();
    BEGIN_ETAG = "</".toCharArray();
  }
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     com.hp.hpl.sparta.ParseCharStream
 * JD-Core Version:    0.6.0
 */