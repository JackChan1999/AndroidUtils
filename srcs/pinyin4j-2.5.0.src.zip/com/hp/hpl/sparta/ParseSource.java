package com.hp.hpl.sparta;

public abstract interface ParseSource
{
  public static final ParseLog DEFAULT_LOG = new DefaultLog();
  public static final int MAXLOOKAHEAD = "<?xml version=\"1.0\" encoding=\"\"".length() + 40;

  public abstract String toString();

  public abstract String getSystemId();

  public abstract int getLineNumber();
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     com.hp.hpl.sparta.ParseSource
 * JD-Core Version:    0.6.0
 */