package com.hp.hpl.sparta;

abstract interface DocumentSource extends ParseSource
{
  public abstract Document getDocument();
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     com.hp.hpl.sparta.DocumentSource
 * JD-Core Version:    0.6.0
 */