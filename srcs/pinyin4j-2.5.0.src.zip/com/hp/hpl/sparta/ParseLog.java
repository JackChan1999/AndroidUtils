package com.hp.hpl.sparta;

public abstract interface ParseLog
{
  public abstract void error(String paramString1, String paramString2, int paramInt);

  public abstract void warning(String paramString1, String paramString2, int paramInt);

  public abstract void note(String paramString1, String paramString2, int paramInt);
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     com.hp.hpl.sparta.ParseLog
 * JD-Core Version:    0.6.0
 */