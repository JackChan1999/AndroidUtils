package com.hp.hpl.sparta;

public class DOMException extends Exception
{
  public short code;
  public static final short DOMSTRING_SIZE_ERR = 2;
  public static final short HIERARCHY_REQUEST_ERR = 3;
  public static final short NOT_FOUND_ERR = 8;

  public DOMException(short paramShort, String paramString)
  {
    super(paramString);
    this.code = paramShort;
  }
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     com.hp.hpl.sparta.DOMException
 * JD-Core Version:    0.6.0
 */