package com.hp.hpl.sparta;

class BuildDocument
  implements DocumentSource, ParseHandler
{
  private final ParseLog log_;
  private Element currentElement_ = null;
  private final Document doc_ = new Document();
  private ParseSource parseSource_ = null;

  public BuildDocument()
  {
    this(null);
  }

  public BuildDocument(ParseLog paramParseLog)
  {
    this.log_ = (paramParseLog == null ? ParseSource.DEFAULT_LOG : paramParseLog);
  }

  public void setParseSource(ParseSource paramParseSource)
  {
    this.parseSource_ = paramParseSource;
    this.doc_.setSystemId(paramParseSource.toString());
  }

  public ParseSource getParseSource()
  {
    return this.parseSource_;
  }

  public String toString()
  {
    if (this.parseSource_ != null)
      return "BuildDoc: " + this.parseSource_.toString();
    return null;
  }

  public String getSystemId()
  {
    if (this.parseSource_ != null)
      return this.parseSource_.getSystemId();
    return null;
  }

  public int getLineNumber()
  {
    if (this.parseSource_ != null)
      return this.parseSource_.getLineNumber();
    return -1;
  }

  public Document getDocument()
  {
    return this.doc_;
  }

  public void startDocument()
  {
  }

  public void endDocument()
  {
  }

  public void startElement(Element paramElement)
  {
    if (this.currentElement_ == null)
      this.doc_.setDocumentElement(paramElement);
    else
      this.currentElement_.appendChild(paramElement);
    this.currentElement_ = paramElement;
  }

  public void endElement(Element paramElement)
  {
    this.currentElement_ = this.currentElement_.getParentNode();
  }

  public void characters(char[] paramArrayOfChar, int paramInt1, int paramInt2)
  {
    Element localElement = this.currentElement_;
    Text localText;
    if ((localElement.getLastChild() instanceof Text))
    {
      localText = (Text)localElement.getLastChild();
      localText.appendData(paramArrayOfChar, paramInt1, paramInt2);
    }
    else
    {
      localText = new Text(new String(paramArrayOfChar, paramInt1, paramInt2));
      localElement.appendChildNoChecking(localText);
    }
  }
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     com.hp.hpl.sparta.BuildDocument
 * JD-Core Version:    0.6.0
 */