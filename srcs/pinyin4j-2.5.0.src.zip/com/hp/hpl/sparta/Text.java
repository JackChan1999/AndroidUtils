package com.hp.hpl.sparta;

import java.io.IOException;
import java.io.Writer;
import java.util.Enumeration;

public class Text extends Node
{
  private StringBuffer text_;

  public Text(String paramString)
  {
    this.text_ = new StringBuffer(paramString);
  }

  public Text(char paramChar)
  {
    this.text_ = new StringBuffer();
    this.text_.append(paramChar);
  }

  public Object clone()
  {
    return new Text(this.text_.toString());
  }

  public void appendData(String paramString)
  {
    this.text_.append(paramString);
    notifyObservers();
  }

  public void appendData(char paramChar)
  {
    this.text_.append(paramChar);
    notifyObservers();
  }

  public void appendData(char[] paramArrayOfChar, int paramInt1, int paramInt2)
  {
    this.text_.append(paramArrayOfChar, paramInt1, paramInt2);
    notifyObservers();
  }

  public String getData()
  {
    return this.text_.toString();
  }

  public void setData(String paramString)
  {
    this.text_ = new StringBuffer(paramString);
    notifyObservers();
  }

  void toXml(Writer paramWriter)
    throws IOException
  {
    String str = this.text_.toString();
    if (str.length() < 50)
    {
      Node.htmlEncode(paramWriter, str);
    }
    else
    {
      paramWriter.write("<![CDATA[");
      paramWriter.write(str);
      paramWriter.write("]]>");
    }
  }

  void toString(Writer paramWriter)
    throws IOException
  {
    paramWriter.write(this.text_.toString());
  }

  public Enumeration xpathSelectElements(String paramString)
  {
    throw new Error("Sorry, not implemented");
  }

  public Enumeration xpathSelectStrings(String paramString)
  {
    throw new Error("Sorry, not implemented");
  }

  public Element xpathSelectElement(String paramString)
  {
    throw new Error("Sorry, not implemented");
  }

  public String xpathSelectString(String paramString)
  {
    throw new Error("Sorry, not implemented");
  }

  public boolean equals(Object paramObject)
  {
    if (this == paramObject)
      return true;
    if (!(paramObject instanceof Text))
      return false;
    Text localText = (Text)paramObject;
    return this.text_.toString().equals(localText.text_.toString());
  }

  protected int computeHashCode()
  {
    return this.text_.toString().hashCode();
  }
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     com.hp.hpl.sparta.Text
 * JD-Core Version:    0.6.0
 */