package com.hp.hpl.sparta;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;

class ParseByteStream
  implements ParseSource
{
  private ParseCharStream parseSource_;

  public ParseByteStream(String paramString1, InputStream paramInputStream, ParseLog paramParseLog, String paramString2, ParseHandler paramParseHandler)
    throws ParseException, IOException
  {
    if (paramParseLog == null)
      paramParseLog = ParseSource.DEFAULT_LOG;
    if (!paramInputStream.markSupported())
      throw new Error("Precondition violation: the InputStream passed to ParseByteStream must support mark");
    paramInputStream.mark(ParseSource.MAXLOOKAHEAD);
    byte[] arrayOfByte = new byte[4];
    int i = paramInputStream.read(arrayOfByte);
    if (paramString2 == null)
      paramString2 = guessEncoding(paramString1, arrayOfByte, i, paramParseLog);
    try
    {
      paramInputStream.reset();
      InputStreamReader localInputStreamReader = new InputStreamReader(paramInputStream, fixEncoding(paramString2));
      try
      {
        this.parseSource_ = new ParseCharStream(paramString1, localInputStreamReader, paramParseLog, paramString2, paramParseHandler);
      }
      catch (IOException localIOException)
      {
        localObject = "euc-jp";
        paramParseLog.note("Problem reading with assumed encoding of " + paramString2 + " so restarting with " + (String)localObject, paramString1, 1);
        paramInputStream.reset();
        try
        {
          localInputStreamReader = new InputStreamReader(paramInputStream, fixEncoding((String)localObject));
        }
        catch (UnsupportedEncodingException localUnsupportedEncodingException1)
        {
          throw new ParseException(paramParseLog, paramString1, 1, 0, (String)localObject, "\"" + (String)localObject + "\" is not a supported encoding");
        }
        this.parseSource_ = new ParseCharStream(paramString1, localInputStreamReader, paramParseLog, null, paramParseHandler);
      }
    }
    catch (EncodingMismatchException localEncodingMismatchException)
    {
      Object localObject;
      String str = localEncodingMismatchException.getDeclaredEncoding();
      paramParseLog.note("Encoding declaration of " + str + " is different that assumed " + paramString2 + " so restarting the parsing with the new encoding", paramString1, 1);
      paramInputStream.reset();
      try
      {
        localObject = new InputStreamReader(paramInputStream, fixEncoding(str));
      }
      catch (UnsupportedEncodingException localUnsupportedEncodingException2)
      {
        throw new ParseException(paramParseLog, paramString1, 1, 0, str, "\"" + str + "\" is not a supported encoding");
      }
      this.parseSource_ = new ParseCharStream(paramString1, (Reader)localObject, paramParseLog, null, paramParseHandler);
    }
  }

  public String toString()
  {
    return this.parseSource_.toString();
  }

  public String getSystemId()
  {
    return this.parseSource_.getSystemId();
  }

  public int getLineNumber()
  {
    return this.parseSource_.getLineNumber();
  }

  private static String guessEncoding(String paramString, byte[] paramArrayOfByte, int paramInt, ParseLog paramParseLog)
    throws IOException
  {
    String str1;
    if (paramInt != 4)
    {
      String str2 = "less than 4 characters in input: \"" + new String(paramArrayOfByte, 0, paramInt) + "\"";
      paramParseLog.error(str2, paramString, 1);
      str1 = "UTF-8";
    }
    else if ((equals(paramArrayOfByte, 65279)) || (equals(paramArrayOfByte, -131072)) || (equals(paramArrayOfByte, 65534)) || (equals(paramArrayOfByte, -16842752)) || (equals(paramArrayOfByte, 60)) || (equals(paramArrayOfByte, 1006632960)) || (equals(paramArrayOfByte, 15360)) || (equals(paramArrayOfByte, 3932160)))
    {
      str1 = "UCS-4";
    }
    else if (equals(paramArrayOfByte, 3932223))
    {
      str1 = "UTF-16BE";
    }
    else if (equals(paramArrayOfByte, 1006649088))
    {
      str1 = "UTF-16LE";
    }
    else if (equals(paramArrayOfByte, 1010792557))
    {
      str1 = "UTF-8";
    }
    else if (equals(paramArrayOfByte, 1282385812))
    {
      str1 = "EBCDIC";
    }
    else if ((equals(paramArrayOfByte, -2)) || (equals(paramArrayOfByte, -257)))
    {
      str1 = "UTF-16";
    }
    else
    {
      str1 = "UTF-8";
    }
    if (!str1.equals("UTF-8"))
      paramParseLog.note("From start " + hex(paramArrayOfByte[0]) + " " + hex(paramArrayOfByte[1]) + " " + hex(paramArrayOfByte[2]) + " " + hex(paramArrayOfByte[3]) + " deduced encoding = " + str1, paramString, 1);
    return str1;
  }

  private static String hex(byte paramByte)
  {
    String str = Integer.toHexString(paramByte);
    switch (str.length())
    {
    case 1:
      return "0" + str;
    case 2:
      return str;
    }
    return str.substring(str.length() - 2);
  }

  private static boolean equals(byte[] paramArrayOfByte, int paramInt)
  {
    return (paramArrayOfByte[0] == (byte)(paramInt >>> 24)) && (paramArrayOfByte[1] == (byte)(paramInt >>> 16 & 0xFF)) && (paramArrayOfByte[2] == (byte)(paramInt >>> 8 & 0xFF)) && (paramArrayOfByte[3] == (byte)(paramInt & 0xFF));
  }

  private static boolean equals(byte[] paramArrayOfByte, short paramShort)
  {
    return (paramArrayOfByte[0] == (byte)(paramShort >>> 8)) && (paramArrayOfByte[1] == (byte)(paramShort & 0xFF));
  }

  private static String fixEncoding(String paramString)
  {
    return paramString.toLowerCase().equals("utf8") ? "UTF-8" : paramString;
  }
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     com.hp.hpl.sparta.ParseByteStream
 * JD-Core Version:    0.6.0
 */