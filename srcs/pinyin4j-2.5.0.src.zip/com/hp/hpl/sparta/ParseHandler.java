package com.hp.hpl.sparta;

public abstract interface ParseHandler
{
  public abstract void setParseSource(ParseSource paramParseSource);

  public abstract ParseSource getParseSource();

  public abstract void startDocument()
    throws ParseException;

  public abstract void endDocument()
    throws ParseException;

  public abstract void startElement(Element paramElement)
    throws ParseException;

  public abstract void endElement(Element paramElement)
    throws ParseException;

  public abstract void characters(char[] paramArrayOfChar, int paramInt1, int paramInt2)
    throws ParseException;
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     com.hp.hpl.sparta.ParseHandler
 * JD-Core Version:    0.6.0
 */