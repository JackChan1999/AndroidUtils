package com.hp.hpl.sparta;

import com.hp.hpl.sparta.xpath.AttrCompareExpr;
import com.hp.hpl.sparta.xpath.AttrEqualsExpr;
import com.hp.hpl.sparta.xpath.AttrExistsExpr;
import com.hp.hpl.sparta.xpath.AttrExpr;
import com.hp.hpl.sparta.xpath.AttrGreaterExpr;
import com.hp.hpl.sparta.xpath.AttrLessExpr;
import com.hp.hpl.sparta.xpath.AttrNotEqualsExpr;
import com.hp.hpl.sparta.xpath.BooleanExpr;
import com.hp.hpl.sparta.xpath.BooleanExprVisitor;
import com.hp.hpl.sparta.xpath.ElementTest;
import com.hp.hpl.sparta.xpath.NodeTest;
import com.hp.hpl.sparta.xpath.PositionEqualsExpr;
import com.hp.hpl.sparta.xpath.Step;
import com.hp.hpl.sparta.xpath.TextCompareExpr;
import com.hp.hpl.sparta.xpath.TextEqualsExpr;
import com.hp.hpl.sparta.xpath.TextExistsExpr;
import com.hp.hpl.sparta.xpath.TextNotEqualsExpr;
import com.hp.hpl.sparta.xpath.TrueExpr;
import com.hp.hpl.sparta.xpath.XPath;
import com.hp.hpl.sparta.xpath.XPathException;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.Enumeration;
import java.util.Vector;

public abstract class Node
{
  private Document doc_ = null;
  private Element parentNode_ = null;
  private Node previousSibling_ = null;
  private Node nextSibling_ = null;
  private Object annotation_ = null;
  private int hash_ = 0;

  void notifyObservers()
  {
    this.hash_ = 0;
    if (this.doc_ != null)
      this.doc_.notifyObservers();
  }

  void setOwnerDocument(Document paramDocument)
  {
    this.doc_ = paramDocument;
  }

  public Document getOwnerDocument()
  {
    return this.doc_;
  }

  public Element getParentNode()
  {
    return this.parentNode_;
  }

  public Node getPreviousSibling()
  {
    return this.previousSibling_;
  }

  public Node getNextSibling()
  {
    return this.nextSibling_;
  }

  public Object getAnnotation()
  {
    return this.annotation_;
  }

  public void setAnnotation(Object paramObject)
  {
    this.annotation_ = paramObject;
  }

  void setParentNode(Element paramElement)
  {
    this.parentNode_ = paramElement;
  }

  void insertAtEndOfLinkedList(Node paramNode)
  {
    this.previousSibling_ = paramNode;
    if (paramNode != null)
      paramNode.nextSibling_ = this;
  }

  void removeFromLinkedList()
  {
    if (this.previousSibling_ != null)
      this.previousSibling_.nextSibling_ = this.nextSibling_;
    if (this.nextSibling_ != null)
      this.nextSibling_.previousSibling_ = this.previousSibling_;
    this.nextSibling_ = null;
    this.previousSibling_ = null;
  }

  void replaceInLinkedList(Node paramNode)
  {
    if (this.previousSibling_ != null)
      this.previousSibling_.nextSibling_ = paramNode;
    if (this.nextSibling_ != null)
      this.nextSibling_.previousSibling_ = paramNode;
    paramNode.nextSibling_ = this.nextSibling_;
    paramNode.previousSibling_ = this.previousSibling_;
    this.nextSibling_ = null;
    this.previousSibling_ = null;
  }

  public String toXml()
    throws IOException
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    OutputStreamWriter localOutputStreamWriter = new OutputStreamWriter(localByteArrayOutputStream);
    toXml(localOutputStreamWriter);
    localOutputStreamWriter.flush();
    return new String(localByteArrayOutputStream.toByteArray());
  }

  public boolean xpathSetStrings(String paramString1, String paramString2)
    throws ParseException
  {
    boolean bool = false;
    try
    {
      int i = paramString1.lastIndexOf('/');
      if ((!paramString1.substring(i + 1).equals("text()")) && (paramString1.charAt(i + 1) != '@'))
        throw new ParseException("Last step of Xpath expression \"" + paramString1 + "\" is not \"text()\" and does not start with a '@'. It starts with a '" + paramString1.charAt(i + 1) + "'");
      String str = paramString1.substring(0, i);
      Object localObject1;
      Object localObject2;
      Object localObject3;
      Object localObject4;
      if (paramString1.charAt(i + 1) == '@')
      {
        localObject1 = paramString1.substring(i + 2);
        if (((String)localObject1).length() == 0)
          throw new ParseException("Xpath expression \"" + paramString1 + "\" specifies zero-length attribute name\"");
        localObject2 = xpathSelectElements(str);
        while (((Enumeration)localObject2).hasMoreElements())
        {
          localObject3 = (Element)((Enumeration)localObject2).nextElement();
          localObject4 = ((Element)localObject3).getAttribute((String)localObject1);
          if (paramString2.equals(localObject4))
            continue;
          ((Element)localObject3).setAttribute((String)localObject1, paramString2);
          bool = true;
        }
      }
      else
      {
        localObject1 = xpathSelectElements(str);
        bool = ((Enumeration)localObject1).hasMoreElements();
        while (((Enumeration)localObject1).hasMoreElements())
        {
          localObject2 = (Element)((Enumeration)localObject1).nextElement();
          localObject3 = new Vector();
          for (localObject4 = ((Element)localObject2).getFirstChild(); localObject4 != null; localObject4 = ((Node)localObject4).getNextSibling())
          {
            if (!(localObject4 instanceof Text))
              continue;
            ((Vector)localObject3).addElement((Text)localObject4);
          }
          Text localText1;
          if (((Vector)localObject3).size() == 0)
          {
            localText1 = new Text(paramString2);
            if (localText1.getData().length() <= 0)
              continue;
            ((Element)localObject2).appendChild(localText1);
            bool = true;
          }
          else
          {
            localText1 = (Text)((Vector)localObject3).elementAt(0);
            if (!localText1.getData().equals(paramString2))
            {
              ((Vector)localObject3).removeElementAt(0);
              localText1.setData(paramString2);
              bool = true;
            }
            for (int j = 0; j < ((Vector)localObject3).size(); j++)
            {
              Text localText2 = (Text)((Vector)localObject3).elementAt(j);
              ((Element)localObject2).removeChild(localText2);
              bool = true;
            }
          }
        }
      }
      return bool;
    }
    catch (DOMException localDOMException)
    {
      throw new Error("Assertion failed " + localDOMException);
    }
    catch (IndexOutOfBoundsException localIndexOutOfBoundsException)
    {
    }
    throw new ParseException("Xpath expression \"" + paramString1 + "\" is not in the form \"xpathExpression/@attributeName\"");
  }

  Element makeMatching(Element paramElement, Step paramStep, String paramString)
    throws ParseException, XPathException
  {
    NodeTest localNodeTest = paramStep.getNodeTest();
    if (!(localNodeTest instanceof ElementTest))
      throw new ParseException("\"" + localNodeTest + "\" in \"" + paramString + "\" is not an element test");
    ElementTest localElementTest = (ElementTest)localNodeTest;
    String str = localElementTest.getTagName();
    Element localElement = new Element(str);
    BooleanExpr localBooleanExpr = paramStep.getPredicate();
    localBooleanExpr.accept(new BooleanExprVisitor(localElement, paramElement, paramString, str)
    {
      private final Element val$newChild;
      private final Element val$parent;
      private final String val$msgContext;
      private final String val$tagName;

      public void visit(TrueExpr paramTrueExpr)
      {
      }

      public void visit(AttrExistsExpr paramAttrExistsExpr)
        throws XPathException
      {
        this.val$newChild.setAttribute(paramAttrExistsExpr.getAttrName(), "something");
      }

      public void visit(AttrEqualsExpr paramAttrEqualsExpr)
        throws XPathException
      {
        this.val$newChild.setAttribute(paramAttrEqualsExpr.getAttrName(), paramAttrEqualsExpr.getAttrValue());
      }

      public void visit(AttrNotEqualsExpr paramAttrNotEqualsExpr)
        throws XPathException
      {
        this.val$newChild.setAttribute(paramAttrNotEqualsExpr.getAttrName(), "not " + paramAttrNotEqualsExpr.getAttrValue());
      }

      public void visit(AttrLessExpr paramAttrLessExpr)
        throws XPathException
      {
        this.val$newChild.setAttribute(paramAttrLessExpr.getAttrName(), Long.toString(-9223372036854775808L));
      }

      public void visit(AttrGreaterExpr paramAttrGreaterExpr)
        throws XPathException
      {
        this.val$newChild.setAttribute(paramAttrGreaterExpr.getAttrName(), Long.toString(9223372036854775807L));
      }

      public void visit(TextExistsExpr paramTextExistsExpr)
        throws XPathException
      {
        this.val$newChild.appendChild(new Text("something"));
      }

      public void visit(TextEqualsExpr paramTextEqualsExpr)
        throws XPathException
      {
        this.val$newChild.appendChild(new Text(paramTextEqualsExpr.getValue()));
      }

      public void visit(TextNotEqualsExpr paramTextNotEqualsExpr)
        throws XPathException
      {
        this.val$newChild.appendChild(new Text("not " + paramTextNotEqualsExpr.getValue()));
      }

      public void visit(PositionEqualsExpr paramPositionEqualsExpr)
        throws XPathException
      {
        int i = paramPositionEqualsExpr.getPosition();
        if ((this.val$parent == null) && (i != 1))
          throw new XPathException(XPath.get(this.val$msgContext), "Position of root node must be 1");
        for (int j = 1; j < i; j++)
          this.val$parent.appendChild(new Element(this.val$tagName));
      }
    });
    return localElement;
  }

  public abstract Enumeration xpathSelectElements(String paramString)
    throws ParseException;

  public abstract Enumeration xpathSelectStrings(String paramString)
    throws ParseException;

  public abstract Element xpathSelectElement(String paramString)
    throws ParseException;

  public abstract String xpathSelectString(String paramString)
    throws ParseException;

  public abstract Object clone();

  public String toString()
  {
    try
    {
      ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
      OutputStreamWriter localOutputStreamWriter = new OutputStreamWriter(localByteArrayOutputStream);
      toString(localOutputStreamWriter);
      localOutputStreamWriter.flush();
      return new String(localByteArrayOutputStream.toByteArray());
    }
    catch (IOException localIOException)
    {
    }
    return super.toString();
  }

  abstract void toString(Writer paramWriter)
    throws IOException;

  abstract void toXml(Writer paramWriter)
    throws IOException;

  protected static void htmlEncode(Writer paramWriter, String paramString)
    throws IOException
  {
    int i = paramString.length();
    int j = 0;
    for (int k = 0; k < i; k++)
    {
      int m = paramString.charAt(k);
      String str;
      if (m >= 128)
        str = "&#" + m + ";";
      else
        switch (m)
        {
        case 60:
          str = "&lt;";
          break;
        case 62:
          str = "&gt;";
          break;
        case 38:
          str = "&amp;";
          break;
        case 34:
          str = "&quot;";
          break;
        case 39:
          str = "&#39;";
          break;
        default:
          str = null;
        }
      if (str == null)
        continue;
      paramWriter.write(paramString, j, k - j);
      paramWriter.write(str);
      j = k + 1;
    }
    if (j < i)
      paramWriter.write(paramString, j, i - j);
  }

  protected abstract int computeHashCode();

  public int hashCode()
  {
    if (this.hash_ == 0)
      this.hash_ = computeHashCode();
    return this.hash_;
  }
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     com.hp.hpl.sparta.Node
 * JD-Core Version:    0.6.0
 */