package com.hp.hpl.sparta;

import com.hp.hpl.sparta.xpath.Step;
import com.hp.hpl.sparta.xpath.XPath;
import com.hp.hpl.sparta.xpath.XPathException;
import java.io.IOException;
import java.io.Writer;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

public class Element extends Node
{
  private static final boolean DEBUG = false;
  private Node firstChild_ = null;
  private Node lastChild_ = null;
  private Hashtable attributes_ = null;
  private Vector attributeNames_ = null;
  private String tagName_ = null;

  public Element(String paramString)
  {
    this.tagName_ = Sparta.intern(paramString);
  }

  Element()
  {
  }

  public Object clone()
  {
    return cloneElement(true);
  }

  public Element cloneShallow()
  {
    return cloneElement(false);
  }

  public Element cloneElement(boolean paramBoolean)
  {
    Element localElement = new Element(this.tagName_);
    Object localObject;
    if (this.attributeNames_ != null)
    {
      Enumeration localEnumeration = this.attributeNames_.elements();
      while (localEnumeration.hasMoreElements())
      {
        localObject = (String)localEnumeration.nextElement();
        localElement.setAttribute((String)localObject, (String)this.attributes_.get(localObject));
      }
    }
    if (paramBoolean)
      for (localObject = this.firstChild_; localObject != null; localObject = ((Node)localObject).getNextSibling())
        localElement.appendChild((Node)((Node)localObject).clone());
    return (Element)localElement;
  }

  public String getTagName()
  {
    return this.tagName_;
  }

  public void setTagName(String paramString)
  {
    this.tagName_ = Sparta.intern(paramString);
    notifyObservers();
  }

  public Node getFirstChild()
  {
    return this.firstChild_;
  }

  public Node getLastChild()
  {
    return this.lastChild_;
  }

  public Enumeration getAttributeNames()
  {
    if (this.attributeNames_ == null)
      return Document.EMPTY;
    return this.attributeNames_.elements();
  }

  public String getAttribute(String paramString)
  {
    return this.attributes_ == null ? null : (String)this.attributes_.get(paramString);
  }

  public void setAttribute(String paramString1, String paramString2)
  {
    if (this.attributes_ == null)
    {
      this.attributes_ = new Hashtable();
      this.attributeNames_ = new Vector();
    }
    if (this.attributes_.get(paramString1) == null)
      this.attributeNames_.addElement(paramString1);
    this.attributes_.put(paramString1, paramString2);
    notifyObservers();
  }

  public void removeAttribute(String paramString)
  {
    if (this.attributes_ == null)
      return;
    this.attributes_.remove(paramString);
    this.attributeNames_.removeElement(paramString);
    notifyObservers();
  }

  void appendChildNoChecking(Node paramNode)
  {
    Element localElement = paramNode.getParentNode();
    if (localElement != null)
      localElement.removeChildNoChecking(paramNode);
    paramNode.insertAtEndOfLinkedList(this.lastChild_);
    if (this.firstChild_ == null)
      this.firstChild_ = paramNode;
    paramNode.setParentNode(this);
    this.lastChild_ = paramNode;
    paramNode.setOwnerDocument(getOwnerDocument());
  }

  public void appendChild(Node paramNode)
  {
    if (!canHaveAsDescendent(paramNode))
      paramNode = (Element)paramNode.clone();
    appendChildNoChecking(paramNode);
    notifyObservers();
  }

  boolean canHaveAsDescendent(Node paramNode)
  {
    if (paramNode == this)
      return false;
    Element localElement = getParentNode();
    if (localElement == null)
      return true;
    return localElement.canHaveAsDescendent(paramNode);
  }

  private boolean removeChildNoChecking(Node paramNode)
  {
    int i = 0;
    for (Node localNode = this.firstChild_; localNode != null; localNode = localNode.getNextSibling())
    {
      if (localNode.equals(paramNode))
      {
        if (this.firstChild_ == localNode)
          this.firstChild_ = localNode.getNextSibling();
        if (this.lastChild_ == localNode)
          this.lastChild_ = localNode.getPreviousSibling();
        localNode.removeFromLinkedList();
        localNode.setParentNode(null);
        localNode.setOwnerDocument(null);
        return true;
      }
      i++;
    }
    return false;
  }

  public void removeChild(Node paramNode)
    throws DOMException
  {
    boolean bool = removeChildNoChecking(paramNode);
    if (!bool)
      throw new DOMException(8, "Cannot find " + paramNode + " in " + this);
    notifyObservers();
  }

  public void replaceChild(Element paramElement, Node paramNode)
    throws DOMException
  {
    replaceChild_(paramElement, paramNode);
    notifyObservers();
  }

  public void replaceChild(Text paramText, Node paramNode)
    throws DOMException
  {
    replaceChild_(paramText, paramNode);
    notifyObservers();
  }

  private void replaceChild_(Node paramNode1, Node paramNode2)
    throws DOMException
  {
    int i = 0;
    for (Node localNode = this.firstChild_; localNode != null; localNode = localNode.getNextSibling())
    {
      if (localNode == paramNode2)
      {
        if (this.firstChild_ == paramNode2)
          this.firstChild_ = paramNode1;
        if (this.lastChild_ == paramNode2)
          this.lastChild_ = paramNode1;
        paramNode2.replaceInLinkedList(paramNode1);
        paramNode1.setParentNode(this);
        paramNode2.setParentNode(null);
        return;
      }
      i++;
    }
    throw new DOMException(8, "Cannot find " + paramNode2 + " in " + this);
  }

  void toString(Writer paramWriter)
    throws IOException
  {
    for (Node localNode = this.firstChild_; localNode != null; localNode = localNode.getNextSibling())
      localNode.toString(paramWriter);
  }

  public void toXml(Writer paramWriter)
    throws IOException
  {
    paramWriter.write("<" + this.tagName_);
    Object localObject;
    if (this.attributeNames_ != null)
    {
      Enumeration localEnumeration = this.attributeNames_.elements();
      while (localEnumeration.hasMoreElements())
      {
        localObject = (String)localEnumeration.nextElement();
        String str = (String)this.attributes_.get(localObject);
        paramWriter.write(" " + (String)localObject + "=\"");
        Node.htmlEncode(paramWriter, str);
        paramWriter.write("\"");
      }
    }
    if (this.firstChild_ == null)
    {
      paramWriter.write("/>");
    }
    else
    {
      paramWriter.write(">");
      for (localObject = this.firstChild_; localObject != null; localObject = ((Node)localObject).getNextSibling())
        ((Node)localObject).toXml(paramWriter);
      paramWriter.write("</" + this.tagName_ + ">");
    }
  }

  private XPathVisitor visitor(String paramString, boolean paramBoolean)
    throws XPathException
  {
    XPath localXPath = XPath.get(paramString);
    if (localXPath.isStringValue() != paramBoolean)
    {
      String str = paramBoolean ? "evaluates to element not string" : "evaluates to string not element";
      throw new XPathException(localXPath, "\"" + localXPath + "\" evaluates to " + str);
    }
    return new XPathVisitor(this, localXPath);
  }

  public Enumeration xpathSelectElements(String paramString)
    throws ParseException
  {
    try
    {
      return visitor(paramString, false).getResultEnumeration();
    }
    catch (XPathException localXPathException)
    {
    }
    throw new ParseException("XPath problem", localXPathException);
  }

  public Enumeration xpathSelectStrings(String paramString)
    throws ParseException
  {
    try
    {
      return visitor(paramString, true).getResultEnumeration();
    }
    catch (XPathException localXPathException)
    {
    }
    throw new ParseException("XPath problem", localXPathException);
  }

  public boolean xpathEnsure(String paramString)
    throws ParseException
  {
    try
    {
      if (xpathSelectElement(paramString) != null)
        return false;
      XPath localXPath = XPath.get(paramString);
      int i = 0;
      Enumeration localEnumeration1 = localXPath.getSteps();
      while (localEnumeration1.hasMoreElements())
      {
        localEnumeration1.nextElement();
        i++;
      }
      Step[] arrayOfStep = new Step[i - 1];
      Enumeration localEnumeration2 = localXPath.getSteps();
      for (int j = 0; j < arrayOfStep.length; j++)
        arrayOfStep[j] = ((Step)localEnumeration2.nextElement());
      Step localStep = (Step)localEnumeration2.nextElement();
      Element localElement;
      if (arrayOfStep.length == 0)
      {
        localElement = this;
      }
      else
      {
        localObject = XPath.get(localXPath.isAbsolute(), arrayOfStep).toString();
        xpathEnsure(((String)localObject).toString());
        localElement = xpathSelectElement((String)localObject);
      }
      Object localObject = makeMatching(localElement, localStep, paramString);
      localElement.appendChildNoChecking((Node)localObject);
      return true;
    }
    catch (XPathException localXPathException)
    {
    }
    throw new ParseException(paramString, localXPathException);
  }

  public Element xpathSelectElement(String paramString)
    throws ParseException
  {
    try
    {
      return visitor(paramString, false).getFirstResultElement();
    }
    catch (XPathException localXPathException)
    {
    }
    throw new ParseException("XPath problem", localXPathException);
  }

  public String xpathSelectString(String paramString)
    throws ParseException
  {
    try
    {
      return visitor(paramString, true).getFirstResultString();
    }
    catch (XPathException localXPathException)
    {
    }
    throw new ParseException("XPath problem", localXPathException);
  }

  public boolean equals(Object paramObject)
  {
    if (this == paramObject)
      return true;
    if (!(paramObject instanceof Element))
      return false;
    Element localElement = (Element)paramObject;
    if (!this.tagName_.equals(localElement.tagName_))
      return false;
    int i = this.attributes_ == null ? 0 : this.attributes_.size();
    int j = localElement.attributes_ == null ? 0 : localElement.attributes_.size();
    if (i != j)
      return false;
    if (this.attributes_ != null)
    {
      Enumeration localEnumeration = this.attributes_.keys();
      while (localEnumeration.hasMoreElements())
      {
        localObject1 = (String)localEnumeration.nextElement();
        localObject2 = (String)this.attributes_.get(localObject1);
        String str = (String)localElement.attributes_.get(localObject1);
        if (!((String)localObject2).equals(str))
          return false;
      }
    }
    Object localObject1 = this.firstChild_;
    for (Object localObject2 = localElement.firstChild_; localObject1 != null; localObject2 = ((Node)localObject2).getNextSibling())
    {
      if (!localObject1.equals(localObject2))
        return false;
      localObject1 = ((Node)localObject1).getNextSibling();
    }
    return true;
  }

  protected int computeHashCode()
  {
    int i = this.tagName_.hashCode();
    if (this.attributes_ != null)
    {
      Enumeration localEnumeration = this.attributes_.keys();
      while (localEnumeration.hasMoreElements())
      {
        localObject = (String)localEnumeration.nextElement();
        i = 31 * i + ((String)localObject).hashCode();
        String str = (String)this.attributes_.get(localObject);
        i = 31 * i + str.hashCode();
      }
    }
    for (Object localObject = this.firstChild_; localObject != null; localObject = ((Node)localObject).getNextSibling())
      i = 31 * i + ((Node)localObject).hashCode();
    return i;
  }

  private void checkInvariant()
  {
  }
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     com.hp.hpl.sparta.Element
 * JD-Core Version:    0.6.0
 */