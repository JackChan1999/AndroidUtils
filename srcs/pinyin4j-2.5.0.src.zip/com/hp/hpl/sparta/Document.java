package com.hp.hpl.sparta;

import com.hp.hpl.sparta.xpath.Step;
import com.hp.hpl.sparta.xpath.XPath;
import com.hp.hpl.sparta.xpath.XPathException;
import java.io.IOException;
import java.io.Writer;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

public class Document extends Node
{
  private static final boolean DEBUG = false;
  private static final Integer ONE = new Integer(1);
  static final Enumeration EMPTY = new EmptyEnumeration();
  private Element rootElement_ = null;
  private String systemId_;
  private Sparta.Cache indices_ = Sparta.newCache();
  private Vector observers_ = new Vector();
  private final Hashtable indexible_ = (Hashtable)null;

  Document(String paramString)
  {
    this.systemId_ = paramString;
  }

  public Document()
  {
    this.systemId_ = "MEMORY";
  }

  public Object clone()
  {
    Document localDocument = new Document(this.systemId_);
    localDocument.rootElement_ = ((Element)this.rootElement_.clone());
    return localDocument;
  }

  public String getSystemId()
  {
    return this.systemId_;
  }

  public void setSystemId(String paramString)
  {
    this.systemId_ = paramString;
    notifyObservers();
  }

  public String toString()
  {
    return this.systemId_;
  }

  public Element getDocumentElement()
  {
    return this.rootElement_;
  }

  public void setDocumentElement(Element paramElement)
  {
    this.rootElement_ = paramElement;
    this.rootElement_.setOwnerDocument(this);
    notifyObservers();
  }

  private XPathVisitor visitor(String paramString, boolean paramBoolean)
    throws XPathException
  {
    if (paramString.charAt(0) != '/')
      paramString = "/" + paramString;
    return visitor(XPath.get(paramString), paramBoolean);
  }

  XPathVisitor visitor(XPath paramXPath, boolean paramBoolean)
    throws XPathException
  {
    if (paramXPath.isStringValue() != paramBoolean)
    {
      String str = paramBoolean ? "evaluates to element not string" : "evaluates to string not element";
      throw new XPathException(paramXPath, "\"" + paramXPath + "\" evaluates to " + str);
    }
    return new XPathVisitor(this, paramXPath);
  }

  public Enumeration xpathSelectElements(String paramString)
    throws ParseException
  {
    try
    {
      if (paramString.charAt(0) != '/')
        paramString = "/" + paramString;
      XPath localXPath = XPath.get(paramString);
      monitor(localXPath);
      return visitor(localXPath, false).getResultEnumeration();
    }
    catch (XPathException localXPathException)
    {
    }
    throw new ParseException("XPath problem", localXPathException);
  }

  void monitor(XPath paramXPath)
    throws XPathException
  {
  }

  public Enumeration xpathSelectStrings(String paramString)
    throws ParseException
  {
    try
    {
      return visitor(paramString, true).getResultEnumeration();
    }
    catch (XPathException localXPathException)
    {
    }
    throw new ParseException("XPath problem", localXPathException);
  }

  public Element xpathSelectElement(String paramString)
    throws ParseException
  {
    try
    {
      if (paramString.charAt(0) != '/')
        paramString = "/" + paramString;
      XPath localXPath = XPath.get(paramString);
      monitor(localXPath);
      return visitor(localXPath, false).getFirstResultElement();
    }
    catch (XPathException localXPathException)
    {
    }
    throw new ParseException("XPath problem", localXPathException);
  }

  public String xpathSelectString(String paramString)
    throws ParseException
  {
    try
    {
      return visitor(paramString, true).getFirstResultString();
    }
    catch (XPathException localXPathException)
    {
    }
    throw new ParseException("XPath problem", localXPathException);
  }

  public boolean xpathEnsure(String paramString)
    throws ParseException
  {
    try
    {
      if (xpathSelectElement(paramString) != null)
        return false;
      XPath localXPath = XPath.get(paramString);
      int i = 0;
      Enumeration localEnumeration1 = localXPath.getSteps();
      while (localEnumeration1.hasMoreElements())
      {
        localEnumeration1.nextElement();
        i++;
      }
      Enumeration localEnumeration2 = localXPath.getSteps();
      Step localStep = (Step)localEnumeration2.nextElement();
      Step[] arrayOfStep = new Step[i - 1];
      for (int j = 0; j < arrayOfStep.length; j++)
        arrayOfStep[j] = ((Step)localEnumeration2.nextElement());
      Element localElement;
      if (this.rootElement_ == null)
      {
        localElement = makeMatching(null, localStep, paramString);
        setDocumentElement(localElement);
      }
      else
      {
        localElement = xpathSelectElement("/" + localStep);
        if (localElement == null)
          throw new ParseException("Existing root element <" + this.rootElement_.getTagName() + "...> does not match first step \"" + localStep + "\" of \"" + paramString);
      }
      if (arrayOfStep.length == 0)
        return true;
      return this.rootElement_.xpathEnsure(XPath.get(false, arrayOfStep).toString());
    }
    catch (XPathException localXPathException)
    {
    }
    throw new ParseException(paramString, localXPathException);
  }

  public boolean xpathHasIndex(String paramString)
  {
    return this.indices_.get(paramString) != null;
  }

  public Index xpathGetIndex(String paramString)
    throws ParseException
  {
    try
    {
      Index localIndex = (Index)this.indices_.get(paramString);
      if (localIndex == null)
      {
        XPath localXPath = XPath.get(paramString);
        localIndex = new Index(localXPath);
        this.indices_.put(paramString, localIndex);
      }
      return localIndex;
    }
    catch (XPathException localXPathException)
    {
    }
    throw new ParseException("XPath problem", localXPathException);
  }

  public void addObserver(Observer paramObserver)
  {
    this.observers_.addElement(paramObserver);
  }

  public void deleteObserver(Observer paramObserver)
  {
    this.observers_.removeElement(paramObserver);
  }

  public void toString(Writer paramWriter)
    throws IOException
  {
    this.rootElement_.toString(paramWriter);
  }

  void notifyObservers()
  {
    Enumeration localEnumeration = this.observers_.elements();
    while (localEnumeration.hasMoreElements())
      ((Observer)localEnumeration.nextElement()).update(this);
  }

  public void toXml(Writer paramWriter)
    throws IOException
  {
    paramWriter.write("<?xml version=\"1.0\" ?>\n");
    this.rootElement_.toXml(paramWriter);
  }

  public boolean equals(Object paramObject)
  {
    if (this == paramObject)
      return true;
    if (!(paramObject instanceof Document))
      return false;
    Document localDocument = (Document)paramObject;
    return this.rootElement_.equals(localDocument.rootElement_);
  }

  protected int computeHashCode()
  {
    return this.rootElement_.hashCode();
  }

  public static abstract interface Observer
  {
    public abstract void update(Document paramDocument);
  }

  public class Index
    implements Document.Observer
  {
    private transient Sparta.Cache dict_ = null;
    private final XPath xpath_;
    private final String attrName_;

    Index(XPath arg2)
      throws XPathException
    {
      Object localObject;
      this.attrName_ = localObject.getIndexingAttrName();
      this.xpath_ = localObject;
      Document.this.addObserver(this);
    }

    public synchronized Enumeration get(String paramString)
      throws ParseException
    {
      if (this.dict_ == null)
        regenerate();
      Vector localVector = (Vector)this.dict_.get(paramString);
      return localVector == null ? Document.EMPTY : localVector.elements();
    }

    public synchronized int size()
      throws ParseException
    {
      if (this.dict_ == null)
        regenerate();
      return this.dict_.size();
    }

    public synchronized void update(Document paramDocument)
    {
      this.dict_ = null;
    }

    private void regenerate()
      throws ParseException
    {
      try
      {
        this.dict_ = Sparta.newCache();
        Enumeration localEnumeration = Document.this.visitor(this.xpath_, false).getResultEnumeration();
        while (localEnumeration.hasMoreElements())
        {
          Element localElement = (Element)localEnumeration.nextElement();
          String str = localElement.getAttribute(this.attrName_);
          Vector localVector = (Vector)this.dict_.get(str);
          if (localVector == null)
          {
            localVector = new Vector(1);
            this.dict_.put(str, localVector);
          }
          localVector.addElement(localElement);
        }
      }
      catch (XPathException localXPathException)
      {
        throw new ParseException("XPath problem", localXPathException);
      }
    }
  }
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     com.hp.hpl.sparta.Document
 * JD-Core Version:    0.6.0
 */