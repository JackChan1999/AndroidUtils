package com.hp.hpl.sparta;

public class DefaultParseHandler
  implements ParseHandler
{
  private ParseSource parseSource_ = null;

  public void setParseSource(ParseSource paramParseSource)
  {
    this.parseSource_ = paramParseSource;
  }

  public ParseSource getParseSource()
  {
    return this.parseSource_;
  }

  public void startDocument()
    throws ParseException
  {
  }

  public void endDocument()
    throws ParseException
  {
  }

  public void startElement(Element paramElement)
    throws ParseException
  {
  }

  public void endElement(Element paramElement)
    throws ParseException
  {
  }

  public void characters(char[] paramArrayOfChar, int paramInt1, int paramInt2)
    throws ParseException
  {
  }
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     com.hp.hpl.sparta.DefaultParseHandler
 * JD-Core Version:    0.6.0
 */