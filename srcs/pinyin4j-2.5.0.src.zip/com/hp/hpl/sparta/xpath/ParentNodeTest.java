package com.hp.hpl.sparta.xpath;

public class ParentNodeTest extends NodeTest
{
  static final ParentNodeTest INSTANCE = new ParentNodeTest();

  public void accept(Visitor paramVisitor)
    throws XPathException
  {
    paramVisitor.visit(this);
  }

  public boolean isStringValue()
  {
    return false;
  }

  public String toString()
  {
    return "..";
  }
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     com.hp.hpl.sparta.xpath.ParentNodeTest
 * JD-Core Version:    0.6.0
 */