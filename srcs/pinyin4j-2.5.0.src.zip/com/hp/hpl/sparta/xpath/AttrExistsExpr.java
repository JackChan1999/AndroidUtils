package com.hp.hpl.sparta.xpath;

public class AttrExistsExpr extends AttrExpr
{
  AttrExistsExpr(String paramString)
  {
    super(paramString);
  }

  public void accept(BooleanExprVisitor paramBooleanExprVisitor)
    throws XPathException
  {
    paramBooleanExprVisitor.visit(this);
  }

  public String toString()
  {
    return "[" + super.toString() + "]";
  }
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     com.hp.hpl.sparta.xpath.AttrExistsExpr
 * JD-Core Version:    0.6.0
 */