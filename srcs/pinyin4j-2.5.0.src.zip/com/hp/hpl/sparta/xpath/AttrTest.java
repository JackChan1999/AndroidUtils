package com.hp.hpl.sparta.xpath;

public class AttrTest extends NodeTest
{
  private final String attrName_;

  AttrTest(String paramString)
  {
    this.attrName_ = paramString;
  }

  public void accept(Visitor paramVisitor)
  {
    paramVisitor.visit(this);
  }

  public boolean isStringValue()
  {
    return true;
  }

  public String getAttrName()
  {
    return this.attrName_;
  }

  public String toString()
  {
    return "@" + this.attrName_;
  }
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     com.hp.hpl.sparta.xpath.AttrTest
 * JD-Core Version:    0.6.0
 */