package com.hp.hpl.sparta.xpath;

public abstract interface BooleanExprVisitor
{
  public abstract void visit(TrueExpr paramTrueExpr);

  public abstract void visit(AttrExistsExpr paramAttrExistsExpr)
    throws XPathException;

  public abstract void visit(AttrEqualsExpr paramAttrEqualsExpr)
    throws XPathException;

  public abstract void visit(AttrNotEqualsExpr paramAttrNotEqualsExpr)
    throws XPathException;

  public abstract void visit(AttrLessExpr paramAttrLessExpr)
    throws XPathException;

  public abstract void visit(AttrGreaterExpr paramAttrGreaterExpr)
    throws XPathException;

  public abstract void visit(TextExistsExpr paramTextExistsExpr)
    throws XPathException;

  public abstract void visit(TextEqualsExpr paramTextEqualsExpr)
    throws XPathException;

  public abstract void visit(TextNotEqualsExpr paramTextNotEqualsExpr)
    throws XPathException;

  public abstract void visit(PositionEqualsExpr paramPositionEqualsExpr)
    throws XPathException;
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     com.hp.hpl.sparta.xpath.BooleanExprVisitor
 * JD-Core Version:    0.6.0
 */