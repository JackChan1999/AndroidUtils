package com.hp.hpl.sparta.xpath;

import com.hp.hpl.sparta.Sparta;

public class ElementTest extends NodeTest
{
  private final String tagName_;

  ElementTest(String paramString)
  {
    this.tagName_ = Sparta.intern(paramString);
  }

  public void accept(Visitor paramVisitor)
  {
    paramVisitor.visit(this);
  }

  public boolean isStringValue()
  {
    return false;
  }

  public String getTagName()
  {
    return this.tagName_;
  }

  public String toString()
  {
    return this.tagName_;
  }
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     com.hp.hpl.sparta.xpath.ElementTest
 * JD-Core Version:    0.6.0
 */