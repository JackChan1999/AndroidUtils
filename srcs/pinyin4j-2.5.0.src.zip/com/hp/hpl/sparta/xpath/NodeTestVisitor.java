package com.hp.hpl.sparta.xpath;

public abstract interface NodeTestVisitor
{
  public abstract void visit(AllElementTest paramAllElementTest);

  public abstract void visit(ThisNodeTest paramThisNodeTest);

  public abstract void visit(ParentNodeTest paramParentNodeTest)
    throws XPathException;

  public abstract void visit(ElementTest paramElementTest);

  public abstract void visit(AttrTest paramAttrTest);

  public abstract void visit(TextTest paramTextTest);
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     com.hp.hpl.sparta.xpath.NodeTestVisitor
 * JD-Core Version:    0.6.0
 */