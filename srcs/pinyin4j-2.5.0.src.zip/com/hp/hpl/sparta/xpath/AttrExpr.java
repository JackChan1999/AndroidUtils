package com.hp.hpl.sparta.xpath;

public abstract class AttrExpr extends BooleanExpr
{
  private final String attrName_;

  AttrExpr(String paramString)
  {
    this.attrName_ = paramString;
  }

  public String getAttrName()
  {
    return this.attrName_;
  }

  public String toString()
  {
    return "@" + this.attrName_;
  }
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     com.hp.hpl.sparta.xpath.AttrExpr
 * JD-Core Version:    0.6.0
 */