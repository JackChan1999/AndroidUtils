package com.hp.hpl.sparta.xpath;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Stack;
import java.util.Vector;

public class XPath
{
  private static final int ASSERTION = 0;
  private Stack steps_ = new Stack();
  private boolean absolute_;
  private String string_;
  private static Hashtable cache_ = new Hashtable();

  private XPath(boolean paramBoolean, Step[] paramArrayOfStep)
  {
    for (int i = 0; i < paramArrayOfStep.length; i++)
      this.steps_.addElement(paramArrayOfStep[i]);
    this.absolute_ = paramBoolean;
    this.string_ = null;
  }

  private XPath(String paramString)
    throws XPathException
  {
    this(paramString, new InputStreamReader(new ByteArrayInputStream(paramString.getBytes())));
  }

  private XPath(String paramString, Reader paramReader)
    throws XPathException
  {
    try
    {
      this.string_ = paramString;
      SimpleStreamTokenizer localSimpleStreamTokenizer = new SimpleStreamTokenizer(paramReader);
      localSimpleStreamTokenizer.ordinaryChar('/');
      localSimpleStreamTokenizer.ordinaryChar('.');
      localSimpleStreamTokenizer.wordChars(':', ':');
      localSimpleStreamTokenizer.wordChars('_', '_');
      boolean bool;
      if (localSimpleStreamTokenizer.nextToken() == 47)
      {
        this.absolute_ = true;
        if (localSimpleStreamTokenizer.nextToken() == 47)
        {
          bool = true;
          localSimpleStreamTokenizer.nextToken();
        }
        else
        {
          bool = false;
        }
      }
      else
      {
        this.absolute_ = false;
        bool = false;
      }
      this.steps_.push(new Step(this, bool, localSimpleStreamTokenizer));
      while (localSimpleStreamTokenizer.ttype == 47)
      {
        if (localSimpleStreamTokenizer.nextToken() == 47)
        {
          bool = true;
          localSimpleStreamTokenizer.nextToken();
        }
        else
        {
          bool = false;
        }
        this.steps_.push(new Step(this, bool, localSimpleStreamTokenizer));
      }
      if (localSimpleStreamTokenizer.ttype != -1)
        throw new XPathException(this, "at end of XPATH expression", localSimpleStreamTokenizer, "end of expression");
    }
    catch (IOException localIOException)
    {
      throw new XPathException(this, localIOException);
    }
  }

  public String toString()
  {
    if (this.string_ == null)
      this.string_ = generateString();
    return this.string_;
  }

  private String generateString()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    int i = 1;
    Enumeration localEnumeration = this.steps_.elements();
    while (localEnumeration.hasMoreElements())
    {
      Step localStep = (Step)localEnumeration.nextElement();
      if ((i == 0) || (this.absolute_))
      {
        localStringBuffer.append('/');
        if (localStep.isMultiLevel())
          localStringBuffer.append('/');
      }
      localStringBuffer.append(localStep.toString());
      i = 0;
    }
    return localStringBuffer.toString();
  }

  public boolean isAbsolute()
  {
    return this.absolute_;
  }

  public boolean isStringValue()
  {
    Step localStep = (Step)this.steps_.peek();
    return localStep.isStringValue();
  }

  public Enumeration getSteps()
  {
    return this.steps_.elements();
  }

  public String getIndexingAttrName()
    throws XPathException
  {
    Step localStep = (Step)this.steps_.peek();
    BooleanExpr localBooleanExpr = localStep.getPredicate();
    if (!(localBooleanExpr instanceof AttrExistsExpr))
      throw new XPathException(this, "has no indexing attribute name (must end with predicate of the form [@attrName]");
    return ((AttrExistsExpr)localBooleanExpr).getAttrName();
  }

  public String getIndexingAttrNameOfEquals()
    throws XPathException
  {
    Step localStep = (Step)this.steps_.peek();
    BooleanExpr localBooleanExpr = localStep.getPredicate();
    if ((localBooleanExpr instanceof AttrEqualsExpr))
      return ((AttrEqualsExpr)localBooleanExpr).getAttrName();
    return null;
  }

  public Object clone()
  {
    Step[] arrayOfStep = new Step[this.steps_.size()];
    Enumeration localEnumeration = this.steps_.elements();
    for (int i = 0; i < arrayOfStep.length; i++)
      arrayOfStep[i] = ((Step)localEnumeration.nextElement());
    return new XPath(this.absolute_, arrayOfStep);
  }

  public static XPath get(String paramString)
    throws XPathException
  {
    synchronized (cache_)
    {
      XPath localXPath = (XPath)cache_.get(paramString);
      if (localXPath == null)
      {
        localXPath = new XPath(paramString);
        cache_.put(paramString, localXPath);
      }
      return localXPath;
    }
  }

  public static XPath get(boolean paramBoolean, Step[] paramArrayOfStep)
  {
    XPath localXPath1 = new XPath(paramBoolean, paramArrayOfStep);
    String str = localXPath1.toString();
    synchronized (cache_)
    {
      XPath localXPath2 = (XPath)cache_.get(str);
      if (localXPath2 == null)
      {
        cache_.put(str, localXPath1);
        return localXPath1;
      }
      return localXPath2;
    }
  }

  public static boolean isStringValue(String paramString)
    throws XPathException, IOException
  {
    return get(paramString).isStringValue();
  }
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     com.hp.hpl.sparta.xpath.XPath
 * JD-Core Version:    0.6.0
 */