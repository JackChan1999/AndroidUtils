package com.hp.hpl.sparta.xpath;

public class TrueExpr extends BooleanExpr
{
  static final TrueExpr INSTANCE = new TrueExpr();

  public void accept(BooleanExprVisitor paramBooleanExprVisitor)
  {
    paramBooleanExprVisitor.visit(this);
  }

  public String toString()
  {
    return "";
  }
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     com.hp.hpl.sparta.xpath.TrueExpr
 * JD-Core Version:    0.6.0
 */