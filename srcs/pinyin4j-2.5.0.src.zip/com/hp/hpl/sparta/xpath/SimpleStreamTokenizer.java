package com.hp.hpl.sparta.xpath;

import java.io.IOException;
import java.io.Reader;

public class SimpleStreamTokenizer
{
  public static final int TT_EOF = -1;
  public static final int TT_NUMBER = -2;
  public static final int TT_WORD = -3;
  public int ttype = -2147483648;
  public int nval = -2147483648;
  public String sval = "";
  private static final int WHITESPACE = -5;
  private static final int QUOTE = -6;
  private final StringBuffer buf_ = new StringBuffer();
  private int nextType_;
  private final Reader reader_;
  private final int[] charType_ = new int[256];
  private boolean pushedBack_ = false;
  private char inQuote_ = '\000';

  public String toString()
  {
    switch (this.ttype)
    {
    case -2:
      return Integer.toString(this.nval);
    case -3:
    case 34:
      return "\"" + this.sval + "\"";
    case 39:
      return "'" + this.sval + "'";
    case -1:
      return "(EOF)";
    }
    return "'" + (char)this.ttype + "'";
  }

  public SimpleStreamTokenizer(Reader paramReader)
    throws IOException
  {
    this.reader_ = paramReader;
    for (int i = 0; i < this.charType_.length; i = (char)(i + 1))
      if (((65 <= i) && (i <= 90)) || ((97 <= i) && (i <= 122)) || (i == 45))
        this.charType_[i] = -3;
      else if ((48 <= i) && (i <= 57))
        this.charType_[i] = -2;
      else if ((0 <= i) && (i <= 32))
        this.charType_[i] = -5;
      else
        this.charType_[i] = i;
    nextToken();
  }

  public void ordinaryChar(char paramChar)
  {
    this.charType_[paramChar] = paramChar;
  }

  public void wordChars(char paramChar1, char paramChar2)
  {
    for (char c = paramChar1; c <= paramChar2; c = (char)(c + '\001'))
      this.charType_[c] = -3;
  }

  public int nextToken()
    throws IOException
  {
    if (this.pushedBack_)
    {
      this.pushedBack_ = false;
      return this.ttype;
    }
    this.ttype = this.nextType_;
    int k;
    do
    {
      k = 0;
      int i;
      int j;
      int m;
      do
      {
        i = this.reader_.read();
        if (i == -1)
        {
          if (this.inQuote_ != 0)
            throw new IOException("Unterminated quote");
          j = -1;
        }
        else
        {
          j = this.charType_[i];
        }
        m = (this.inQuote_ == 0) && (j == -5) ? 1 : 0;
        k = (k != 0) || (m != 0) ? 1 : 0;
      }
      while (m != 0);
      if ((j == 39) || (j == 34))
        if (this.inQuote_ == 0)
          this.inQuote_ = (char)j;
        else if (this.inQuote_ == j)
          this.inQuote_ = '\000';
      if (this.inQuote_ != 0)
        j = this.inQuote_;
      k = (k != 0) || ((this.ttype >= -1) && (this.ttype != 39) && (this.ttype != 34)) || (this.ttype != j) ? 1 : 0;
      if (k != 0)
      {
        switch (this.ttype)
        {
        case -3:
          this.sval = this.buf_.toString();
          this.buf_.setLength(0);
          break;
        case 34:
        case 39:
          this.sval = this.buf_.toString().substring(1, this.buf_.length() - 1);
          this.buf_.setLength(0);
          break;
        case -2:
          this.nval = Integer.parseInt(this.buf_.toString());
          this.buf_.setLength(0);
          break;
        }
        if (j != -5)
          this.nextType_ = (j == -6 ? i : j);
      }
      switch (j)
      {
      case -3:
      case -2:
      case 34:
      case 39:
        this.buf_.append((char)i);
      }
    }
    while (k == 0);
    return this.ttype;
  }

  public void pushBack()
  {
    this.pushedBack_ = true;
  }
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     com.hp.hpl.sparta.xpath.SimpleStreamTokenizer
 * JD-Core Version:    0.6.0
 */