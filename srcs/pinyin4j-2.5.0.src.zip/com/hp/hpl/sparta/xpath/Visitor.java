package com.hp.hpl.sparta.xpath;

public abstract interface Visitor extends NodeTestVisitor, BooleanExprVisitor
{
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     com.hp.hpl.sparta.xpath.Visitor
 * JD-Core Version:    0.6.0
 */