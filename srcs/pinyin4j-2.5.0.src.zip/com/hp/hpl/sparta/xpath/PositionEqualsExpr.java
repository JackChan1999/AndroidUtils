package com.hp.hpl.sparta.xpath;

public class PositionEqualsExpr extends BooleanExpr
{
  private final int position_;

  public PositionEqualsExpr(int paramInt)
  {
    this.position_ = paramInt;
  }

  public void accept(BooleanExprVisitor paramBooleanExprVisitor)
    throws XPathException
  {
    paramBooleanExprVisitor.visit(this);
  }

  public int getPosition()
  {
    return this.position_;
  }

  public String toString()
  {
    return "[" + this.position_ + "]";
  }
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     com.hp.hpl.sparta.xpath.PositionEqualsExpr
 * JD-Core Version:    0.6.0
 */