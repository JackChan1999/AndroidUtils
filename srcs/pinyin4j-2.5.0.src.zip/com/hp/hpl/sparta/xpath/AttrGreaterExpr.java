package com.hp.hpl.sparta.xpath;

public class AttrGreaterExpr extends AttrRelationalExpr
{
  public AttrGreaterExpr(String paramString, int paramInt)
  {
    super(paramString, paramInt);
  }

  public void accept(BooleanExprVisitor paramBooleanExprVisitor)
    throws XPathException
  {
    paramBooleanExprVisitor.visit(this);
  }

  public String toString()
  {
    return toString(">");
  }
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     com.hp.hpl.sparta.xpath.AttrGreaterExpr
 * JD-Core Version:    0.6.0
 */