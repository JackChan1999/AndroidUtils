package com.hp.hpl.sparta.xpath;

import java.io.IOException;

public class ExprFactory
{
  static BooleanExpr createExpr(XPath paramXPath, SimpleStreamTokenizer paramSimpleStreamTokenizer)
    throws XPathException, IOException
  {
    switch (paramSimpleStreamTokenizer.ttype)
    {
    default:
      throw new XPathException(paramXPath, "at beginning of expression", paramSimpleStreamTokenizer, "@, number, or text()");
    case -2:
      int i = paramSimpleStreamTokenizer.nval;
      paramSimpleStreamTokenizer.nextToken();
      return new PositionEqualsExpr(i);
    case 64:
      if (paramSimpleStreamTokenizer.nextToken() != -3)
        throw new XPathException(paramXPath, "after @", paramSimpleStreamTokenizer, "name");
      String str1 = paramSimpleStreamTokenizer.sval;
      String str2;
      int j;
      switch (paramSimpleStreamTokenizer.nextToken())
      {
      case 61:
        paramSimpleStreamTokenizer.nextToken();
        if ((paramSimpleStreamTokenizer.ttype != 34) && (paramSimpleStreamTokenizer.ttype != 39))
          throw new XPathException(paramXPath, "right hand side of equals", paramSimpleStreamTokenizer, "quoted string");
        str2 = paramSimpleStreamTokenizer.sval;
        paramSimpleStreamTokenizer.nextToken();
        return new AttrEqualsExpr(str1, str2);
      case 60:
        paramSimpleStreamTokenizer.nextToken();
        if ((paramSimpleStreamTokenizer.ttype == 34) || (paramSimpleStreamTokenizer.ttype == 39))
          j = Integer.parseInt(paramSimpleStreamTokenizer.sval);
        else if (paramSimpleStreamTokenizer.ttype == -2)
          j = paramSimpleStreamTokenizer.nval;
        else
          throw new XPathException(paramXPath, "right hand side of less-than", paramSimpleStreamTokenizer, "quoted string or number");
        paramSimpleStreamTokenizer.nextToken();
        return new AttrLessExpr(str1, j);
      case 62:
        paramSimpleStreamTokenizer.nextToken();
        if ((paramSimpleStreamTokenizer.ttype == 34) || (paramSimpleStreamTokenizer.ttype == 39))
          j = Integer.parseInt(paramSimpleStreamTokenizer.sval);
        else if (paramSimpleStreamTokenizer.ttype == -2)
          j = paramSimpleStreamTokenizer.nval;
        else
          throw new XPathException(paramXPath, "right hand side of greater-than", paramSimpleStreamTokenizer, "quoted string or number");
        paramSimpleStreamTokenizer.nextToken();
        return new AttrGreaterExpr(str1, j);
      case 33:
        paramSimpleStreamTokenizer.nextToken();
        if (paramSimpleStreamTokenizer.ttype != 61)
          throw new XPathException(paramXPath, "after !", paramSimpleStreamTokenizer, "=");
        paramSimpleStreamTokenizer.nextToken();
        if ((paramSimpleStreamTokenizer.ttype != 34) && (paramSimpleStreamTokenizer.ttype != 39))
          throw new XPathException(paramXPath, "right hand side of !=", paramSimpleStreamTokenizer, "quoted string");
        str2 = paramSimpleStreamTokenizer.sval;
        paramSimpleStreamTokenizer.nextToken();
        return new AttrNotEqualsExpr(str1, str2);
      }
      return new AttrExistsExpr(str1);
    case -3:
    }
    if (!paramSimpleStreamTokenizer.sval.equals("text"))
      throw new XPathException(paramXPath, "at beginning of expression", paramSimpleStreamTokenizer, "text()");
    if (paramSimpleStreamTokenizer.nextToken() != 40)
      throw new XPathException(paramXPath, "after text", paramSimpleStreamTokenizer, "(");
    if (paramSimpleStreamTokenizer.nextToken() != 41)
      throw new XPathException(paramXPath, "after text(", paramSimpleStreamTokenizer, ")");
    String str3;
    switch (paramSimpleStreamTokenizer.nextToken())
    {
    case 61:
      paramSimpleStreamTokenizer.nextToken();
      if ((paramSimpleStreamTokenizer.ttype != 34) && (paramSimpleStreamTokenizer.ttype != 39))
        throw new XPathException(paramXPath, "right hand side of equals", paramSimpleStreamTokenizer, "quoted string");
      str3 = paramSimpleStreamTokenizer.sval;
      paramSimpleStreamTokenizer.nextToken();
      return new TextEqualsExpr(str3);
    case 33:
      paramSimpleStreamTokenizer.nextToken();
      if (paramSimpleStreamTokenizer.ttype != 61)
        throw new XPathException(paramXPath, "after !", paramSimpleStreamTokenizer, "=");
      paramSimpleStreamTokenizer.nextToken();
      if ((paramSimpleStreamTokenizer.ttype != 34) && (paramSimpleStreamTokenizer.ttype != 39))
        throw new XPathException(paramXPath, "right hand side of !=", paramSimpleStreamTokenizer, "quoted string");
      str3 = paramSimpleStreamTokenizer.sval;
      paramSimpleStreamTokenizer.nextToken();
      return new TextNotEqualsExpr(str3);
    }
    return TextExistsExpr.INSTANCE;
  }
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     com.hp.hpl.sparta.xpath.ExprFactory
 * JD-Core Version:    0.6.0
 */