package com.hp.hpl.sparta.xpath;

public class TextNotEqualsExpr extends TextCompareExpr
{
  TextNotEqualsExpr(String paramString)
  {
    super(paramString);
  }

  public void accept(BooleanExprVisitor paramBooleanExprVisitor)
    throws XPathException
  {
    paramBooleanExprVisitor.visit(this);
  }

  public String toString()
  {
    return toString("!=");
  }
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     com.hp.hpl.sparta.xpath.TextNotEqualsExpr
 * JD-Core Version:    0.6.0
 */