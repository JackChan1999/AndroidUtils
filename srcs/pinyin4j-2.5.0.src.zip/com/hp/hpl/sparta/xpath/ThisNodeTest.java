package com.hp.hpl.sparta.xpath;

public class ThisNodeTest extends NodeTest
{
  static final ThisNodeTest INSTANCE = new ThisNodeTest();

  public void accept(Visitor paramVisitor)
  {
    paramVisitor.visit(this);
  }

  public boolean isStringValue()
  {
    return false;
  }

  public String toString()
  {
    return ".";
  }
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     com.hp.hpl.sparta.xpath.ThisNodeTest
 * JD-Core Version:    0.6.0
 */