package com.hp.hpl.sparta.xpath;

public class AttrNotEqualsExpr extends AttrCompareExpr
{
  AttrNotEqualsExpr(String paramString1, String paramString2)
  {
    super(paramString1, paramString2);
  }

  public void accept(BooleanExprVisitor paramBooleanExprVisitor)
    throws XPathException
  {
    paramBooleanExprVisitor.visit(this);
  }

  public String toString()
  {
    return toString("!=");
  }
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     com.hp.hpl.sparta.xpath.AttrNotEqualsExpr
 * JD-Core Version:    0.6.0
 */