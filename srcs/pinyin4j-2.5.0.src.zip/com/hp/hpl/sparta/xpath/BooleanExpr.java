package com.hp.hpl.sparta.xpath;

public abstract class BooleanExpr
{
  public abstract void accept(BooleanExprVisitor paramBooleanExprVisitor)
    throws XPathException;
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     com.hp.hpl.sparta.xpath.BooleanExpr
 * JD-Core Version:    0.6.0
 */