package com.hp.hpl.sparta.xpath;

public class AllElementTest extends NodeTest
{
  static final AllElementTest INSTANCE = new AllElementTest();

  public void accept(Visitor paramVisitor)
  {
    paramVisitor.visit(this);
  }

  public boolean isStringValue()
  {
    return false;
  }

  public String toString()
  {
    return "*";
  }
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     com.hp.hpl.sparta.xpath.AllElementTest
 * JD-Core Version:    0.6.0
 */