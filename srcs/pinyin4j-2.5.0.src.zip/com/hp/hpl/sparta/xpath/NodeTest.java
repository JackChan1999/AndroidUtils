package com.hp.hpl.sparta.xpath;

public abstract class NodeTest
{
  public abstract void accept(Visitor paramVisitor)
    throws XPathException;

  public abstract boolean isStringValue();
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     com.hp.hpl.sparta.xpath.NodeTest
 * JD-Core Version:    0.6.0
 */