package com.hp.hpl.sparta;

import com.hp.hpl.sparta.xpath.AllElementTest;
import com.hp.hpl.sparta.xpath.AttrCompareExpr;
import com.hp.hpl.sparta.xpath.AttrEqualsExpr;
import com.hp.hpl.sparta.xpath.AttrExistsExpr;
import com.hp.hpl.sparta.xpath.AttrExpr;
import com.hp.hpl.sparta.xpath.AttrGreaterExpr;
import com.hp.hpl.sparta.xpath.AttrLessExpr;
import com.hp.hpl.sparta.xpath.AttrNotEqualsExpr;
import com.hp.hpl.sparta.xpath.AttrRelationalExpr;
import com.hp.hpl.sparta.xpath.AttrTest;
import com.hp.hpl.sparta.xpath.BooleanExpr;
import com.hp.hpl.sparta.xpath.ElementTest;
import com.hp.hpl.sparta.xpath.NodeTest;
import com.hp.hpl.sparta.xpath.ParentNodeTest;
import com.hp.hpl.sparta.xpath.PositionEqualsExpr;
import com.hp.hpl.sparta.xpath.Step;
import com.hp.hpl.sparta.xpath.TextCompareExpr;
import com.hp.hpl.sparta.xpath.TextEqualsExpr;
import com.hp.hpl.sparta.xpath.TextExistsExpr;
import com.hp.hpl.sparta.xpath.TextNotEqualsExpr;
import com.hp.hpl.sparta.xpath.TextTest;
import com.hp.hpl.sparta.xpath.ThisNodeTest;
import com.hp.hpl.sparta.xpath.TrueExpr;
import com.hp.hpl.sparta.xpath.Visitor;
import com.hp.hpl.sparta.xpath.XPath;
import com.hp.hpl.sparta.xpath.XPathException;
import java.util.Enumeration;
import java.util.Vector;

class XPathVisitor
  implements Visitor
{
  private static final Boolean TRUE = new Boolean(true);
  private static final Boolean FALSE = new Boolean(false);
  private final NodeListWithPosition nodelistRaw_ = new NodeListWithPosition();
  private Vector nodelistFiltered_ = new Vector();
  private Enumeration nodesetIterator_ = null;
  private Object node_ = null;
  private final BooleanStack exprStack_ = new BooleanStack(null);
  private Node contextNode_;
  private boolean multiLevel_;
  private XPath xpath_;

  private XPathVisitor(XPath paramXPath, Node paramNode)
    throws XPathException
  {
    this.xpath_ = paramXPath;
    this.contextNode_ = paramNode;
    this.nodelistFiltered_ = new Vector(1);
    this.nodelistFiltered_.addElement(this.contextNode_);
    Enumeration localEnumeration = paramXPath.getSteps();
    while (localEnumeration.hasMoreElements())
    {
      Step localStep = (Step)localEnumeration.nextElement();
      this.multiLevel_ = localStep.isMultiLevel();
      this.nodesetIterator_ = null;
      localStep.getNodeTest().accept(this);
      this.nodesetIterator_ = this.nodelistRaw_.iterator();
      this.nodelistFiltered_.removeAllElements();
      BooleanExpr localBooleanExpr = localStep.getPredicate();
      while (this.nodesetIterator_.hasMoreElements())
      {
        this.node_ = this.nodesetIterator_.nextElement();
        localBooleanExpr.accept(this);
        Boolean localBoolean = this.exprStack_.pop();
        if (!localBoolean.booleanValue())
          continue;
        this.nodelistFiltered_.addElement(this.node_);
      }
    }
  }

  public XPathVisitor(Element paramElement, XPath paramXPath)
    throws XPathException
  {
    this(paramXPath, paramElement);
    if (paramXPath.isAbsolute())
      throw new XPathException(paramXPath, "Cannot use element as context node for absolute xpath");
  }

  public XPathVisitor(Document paramDocument, XPath paramXPath)
    throws XPathException
  {
    this(paramXPath, paramDocument);
  }

  public void visit(ThisNodeTest paramThisNodeTest)
  {
    this.nodelistRaw_.removeAllElements();
    this.nodelistRaw_.add(this.contextNode_, 1);
  }

  public void visit(ParentNodeTest paramParentNodeTest)
    throws XPathException
  {
    this.nodelistRaw_.removeAllElements();
    Element localElement = this.contextNode_.getParentNode();
    if (localElement == null)
      throw new XPathException(this.xpath_, "Illegal attempt to apply \"..\" to node with no parent.");
    this.nodelistRaw_.add(localElement, 1);
  }

  public void visit(AllElementTest paramAllElementTest)
  {
    Vector localVector = this.nodelistFiltered_;
    this.nodelistRaw_.removeAllElements();
    Enumeration localEnumeration = localVector.elements();
    while (localEnumeration.hasMoreElements())
    {
      Object localObject = localEnumeration.nextElement();
      if ((localObject instanceof Element))
      {
        accumulateElements((Element)localObject);
      }
      else
      {
        if (!(localObject instanceof Document))
          continue;
        accumulateElements((Document)localObject);
      }
    }
  }

  private void accumulateElements(Document paramDocument)
  {
    Element localElement = paramDocument.getDocumentElement();
    this.nodelistRaw_.add(localElement, 1);
    if (this.multiLevel_)
      accumulateElements(localElement);
  }

  private void accumulateElements(Element paramElement)
  {
    int i = 0;
    for (Node localNode = paramElement.getFirstChild(); localNode != null; localNode = localNode.getNextSibling())
    {
      if (!(localNode instanceof Element))
        continue;
      i++;
      this.nodelistRaw_.add(localNode, i);
      if (!this.multiLevel_)
        continue;
      accumulateElements((Element)localNode);
    }
  }

  public void visit(TextTest paramTextTest)
  {
    Vector localVector = this.nodelistFiltered_;
    this.nodelistRaw_.removeAllElements();
    Enumeration localEnumeration = localVector.elements();
    while (localEnumeration.hasMoreElements())
    {
      Object localObject = localEnumeration.nextElement();
      if (!(localObject instanceof Element))
        continue;
      Element localElement = (Element)localObject;
      for (Node localNode = localElement.getFirstChild(); localNode != null; localNode = localNode.getNextSibling())
      {
        if (!(localNode instanceof Text))
          continue;
        this.nodelistRaw_.add(((Text)localNode).getData());
      }
    }
  }

  public void visit(ElementTest paramElementTest)
  {
    String str = paramElementTest.getTagName();
    Vector localVector = this.nodelistFiltered_;
    int i = localVector.size();
    this.nodelistRaw_.removeAllElements();
    for (int j = 0; j < i; j++)
    {
      Object localObject = localVector.elementAt(j);
      if ((localObject instanceof Element))
      {
        accumulateMatchingElements((Element)localObject, str);
      }
      else
      {
        if (!(localObject instanceof Document))
          continue;
        accumulateMatchingElements((Document)localObject, str);
      }
    }
  }

  private void accumulateMatchingElements(Document paramDocument, String paramString)
  {
    Element localElement = paramDocument.getDocumentElement();
    if (localElement == null)
      return;
    if (localElement.getTagName() == paramString)
      this.nodelistRaw_.add(localElement, 1);
    if (this.multiLevel_)
      accumulateMatchingElements(localElement, paramString);
  }

  private void accumulateMatchingElements(Element paramElement, String paramString)
  {
    int i = 0;
    for (Node localNode = paramElement.getFirstChild(); localNode != null; localNode = localNode.getNextSibling())
    {
      if (!(localNode instanceof Element))
        continue;
      Element localElement = (Element)localNode;
      if (localElement.getTagName() == paramString)
      {
        i++;
        this.nodelistRaw_.add(localElement, i);
      }
      if (!this.multiLevel_)
        continue;
      accumulateMatchingElements(localElement, paramString);
    }
  }

  public void visit(AttrTest paramAttrTest)
  {
    Vector localVector = this.nodelistFiltered_;
    this.nodelistRaw_.removeAllElements();
    Enumeration localEnumeration = localVector.elements();
    while (localEnumeration.hasMoreElements())
    {
      Node localNode = (Node)localEnumeration.nextElement();
      if (!(localNode instanceof Element))
        continue;
      Element localElement = (Element)localNode;
      String str = localElement.getAttribute(paramAttrTest.getAttrName());
      if (str == null)
        continue;
      this.nodelistRaw_.add(str);
    }
  }

  public void visit(TrueExpr paramTrueExpr)
  {
    this.exprStack_.push(TRUE);
  }

  public void visit(AttrExistsExpr paramAttrExistsExpr)
    throws XPathException
  {
    if (!(this.node_ instanceof Element))
      throw new XPathException(this.xpath_, "Cannot test attribute of document");
    Element localElement = (Element)this.node_;
    String str = localElement.getAttribute(paramAttrExistsExpr.getAttrName());
    int i = (str != null) && (str.length() > 0) ? 1 : 0;
    this.exprStack_.push(i != 0 ? TRUE : FALSE);
  }

  public void visit(AttrEqualsExpr paramAttrEqualsExpr)
    throws XPathException
  {
    if (!(this.node_ instanceof Element))
      throw new XPathException(this.xpath_, "Cannot test attribute of document");
    Element localElement = (Element)this.node_;
    String str = localElement.getAttribute(paramAttrEqualsExpr.getAttrName());
    boolean bool = paramAttrEqualsExpr.getAttrValue().equals(str);
    this.exprStack_.push(bool ? TRUE : FALSE);
  }

  public void visit(AttrNotEqualsExpr paramAttrNotEqualsExpr)
    throws XPathException
  {
    if (!(this.node_ instanceof Element))
      throw new XPathException(this.xpath_, "Cannot test attribute of document");
    Element localElement = (Element)this.node_;
    String str = localElement.getAttribute(paramAttrNotEqualsExpr.getAttrName());
    int i = !paramAttrNotEqualsExpr.getAttrValue().equals(str) ? 1 : 0;
    this.exprStack_.push(i != 0 ? TRUE : FALSE);
  }

  public void visit(AttrLessExpr paramAttrLessExpr)
    throws XPathException
  {
    if (!(this.node_ instanceof Element))
      throw new XPathException(this.xpath_, "Cannot test attribute of document");
    Element localElement = (Element)this.node_;
    long l = Long.parseLong(localElement.getAttribute(paramAttrLessExpr.getAttrName()));
    int i = l < paramAttrLessExpr.getAttrValue() ? 1 : 0;
    this.exprStack_.push(i != 0 ? TRUE : FALSE);
  }

  public void visit(AttrGreaterExpr paramAttrGreaterExpr)
    throws XPathException
  {
    if (!(this.node_ instanceof Element))
      throw new XPathException(this.xpath_, "Cannot test attribute of document");
    Element localElement = (Element)this.node_;
    long l = Long.parseLong(localElement.getAttribute(paramAttrGreaterExpr.getAttrName()));
    int i = l > paramAttrGreaterExpr.getAttrValue() ? 1 : 0;
    this.exprStack_.push(i != 0 ? TRUE : FALSE);
  }

  public void visit(TextExistsExpr paramTextExistsExpr)
    throws XPathException
  {
    if (!(this.node_ instanceof Element))
      throw new XPathException(this.xpath_, "Cannot test attribute of document");
    Element localElement = (Element)this.node_;
    for (Node localNode = localElement.getFirstChild(); localNode != null; localNode = localNode.getNextSibling())
    {
      if (!(localNode instanceof Text))
        continue;
      this.exprStack_.push(TRUE);
      return;
    }
    this.exprStack_.push(FALSE);
  }

  public void visit(TextEqualsExpr paramTextEqualsExpr)
    throws XPathException
  {
    if (!(this.node_ instanceof Element))
      throw new XPathException(this.xpath_, "Cannot test attribute of document");
    Element localElement = (Element)this.node_;
    for (Node localNode = localElement.getFirstChild(); localNode != null; localNode = localNode.getNextSibling())
    {
      if (!(localNode instanceof Text))
        continue;
      Text localText = (Text)localNode;
      if (!localText.getData().equals(paramTextEqualsExpr.getValue()))
        continue;
      this.exprStack_.push(TRUE);
      return;
    }
    this.exprStack_.push(FALSE);
  }

  public void visit(TextNotEqualsExpr paramTextNotEqualsExpr)
    throws XPathException
  {
    if (!(this.node_ instanceof Element))
      throw new XPathException(this.xpath_, "Cannot test attribute of document");
    Element localElement = (Element)this.node_;
    for (Node localNode = localElement.getFirstChild(); localNode != null; localNode = localNode.getNextSibling())
    {
      if (!(localNode instanceof Text))
        continue;
      Text localText = (Text)localNode;
      if (localText.getData().equals(paramTextNotEqualsExpr.getValue()))
        continue;
      this.exprStack_.push(TRUE);
      return;
    }
    this.exprStack_.push(FALSE);
  }

  public void visit(PositionEqualsExpr paramPositionEqualsExpr)
    throws XPathException
  {
    if (!(this.node_ instanceof Element))
      throw new XPathException(this.xpath_, "Cannot test position of document");
    Element localElement = (Element)this.node_;
    int i = this.nodelistRaw_.position(localElement) == paramPositionEqualsExpr.getPosition() ? 1 : 0;
    this.exprStack_.push(i != 0 ? TRUE : FALSE);
  }

  public Enumeration getResultEnumeration()
  {
    return this.nodelistFiltered_.elements();
  }

  public Element getFirstResultElement()
  {
    return this.nodelistFiltered_.size() == 0 ? null : (Element)this.nodelistFiltered_.elementAt(0);
  }

  public String getFirstResultString()
  {
    return this.nodelistFiltered_.size() == 0 ? null : this.nodelistFiltered_.elementAt(0).toString();
  }

  private static class BooleanStack
  {
    private Item top_ = null;

    private BooleanStack()
    {
    }

    void push(Boolean paramBoolean)
    {
      this.top_ = new Item(paramBoolean, this.top_);
    }

    Boolean pop()
    {
      Boolean localBoolean = this.top_.bool;
      this.top_ = this.top_.prev;
      return localBoolean;
    }

    BooleanStack(XPathVisitor.1 param1)
    {
      this();
    }

    private static class Item
    {
      final Boolean bool;
      final Item prev;

      Item(Boolean paramBoolean, Item paramItem)
      {
        this.bool = paramBoolean;
        this.prev = paramItem;
      }
    }
  }
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     com.hp.hpl.sparta.XPathVisitor
 * JD-Core Version:    0.6.0
 */