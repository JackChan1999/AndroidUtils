package com.hp.hpl.sparta;

import java.io.IOException;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

class NodeListWithPosition
{
  private static final Integer ONE = new Integer(1);
  private static final Integer TWO = new Integer(2);
  private static final Integer THREE = new Integer(3);
  private static final Integer FOUR = new Integer(4);
  private static final Integer FIVE = new Integer(5);
  private static final Integer SIX = new Integer(6);
  private static final Integer SEVEN = new Integer(7);
  private static final Integer EIGHT = new Integer(8);
  private static final Integer NINE = new Integer(9);
  private static final Integer TEN = new Integer(10);
  private final Vector vector_ = new Vector();
  private Hashtable positions_ = new Hashtable();

  Enumeration iterator()
  {
    return this.vector_.elements();
  }

  void removeAllElements()
  {
    this.vector_.removeAllElements();
    this.positions_.clear();
  }

  void add(String paramString)
  {
    this.vector_.addElement(paramString);
  }

  private static Integer identity(Node paramNode)
  {
    return new Integer(System.identityHashCode(paramNode));
  }

  void add(Node paramNode, int paramInt)
  {
    this.vector_.addElement(paramNode);
    Integer localInteger;
    switch (paramInt)
    {
    case 1:
      localInteger = ONE;
      break;
    case 2:
      localInteger = TWO;
      break;
    case 3:
      localInteger = THREE;
      break;
    case 4:
      localInteger = FOUR;
      break;
    case 5:
      localInteger = FIVE;
      break;
    case 6:
      localInteger = SIX;
      break;
    case 7:
      localInteger = SEVEN;
      break;
    case 8:
      localInteger = EIGHT;
      break;
    case 9:
      localInteger = NINE;
      break;
    case 10:
      localInteger = TEN;
      break;
    default:
      localInteger = new Integer(paramInt);
    }
    this.positions_.put(identity(paramNode), localInteger);
  }

  int position(Node paramNode)
  {
    return ((Integer)this.positions_.get(identity(paramNode))).intValue();
  }

  public String toString()
  {
    try
    {
      StringBuffer localStringBuffer = new StringBuffer("{ ");
      Enumeration localEnumeration = this.vector_.elements();
      while (localEnumeration.hasMoreElements())
      {
        Object localObject = localEnumeration.nextElement();
        if ((localObject instanceof String))
        {
          localStringBuffer.append("String(" + localObject + ") ");
        }
        else
        {
          Node localNode = (Node)localObject;
          localStringBuffer.append("Node(" + localNode.toXml() + ")[" + this.positions_.get(identity(localNode)) + "] ");
        }
      }
      localStringBuffer.append("}");
      return localStringBuffer.toString();
    }
    catch (IOException localIOException)
    {
    }
    return localIOException.toString();
  }
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     com.hp.hpl.sparta.NodeListWithPosition
 * JD-Core Version:    0.6.0
 */