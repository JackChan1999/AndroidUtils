package com.hp.hpl.sparta;

class CharCircBuffer
{
  private final int[] buf_;
  private int next_ = 0;
  private int total_ = 0;
  private boolean enabled_ = true;

  CharCircBuffer(int paramInt)
  {
    this.buf_ = new int[paramInt];
  }

  void enable()
  {
    this.enabled_ = true;
  }

  void disable()
  {
    this.enabled_ = false;
  }

  void addInt(int paramInt)
  {
    addRaw(paramInt + 65536);
  }

  void addChar(char paramChar)
  {
    addRaw(paramChar);
  }

  private void addRaw(int paramInt)
  {
    if (this.enabled_)
    {
      this.buf_[this.next_] = paramInt;
      this.next_ = ((this.next_ + 1) % this.buf_.length);
      this.total_ += 1;
    }
  }

  void addString(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i = arrayOfChar.length;
    for (int j = 0; j < i; j++)
      addChar(arrayOfChar[j]);
  }

  public String toString()
  {
    StringBuffer localStringBuffer = new StringBuffer(11 * this.buf_.length / 10);
    int i = this.total_ < this.buf_.length ? this.buf_.length - this.total_ : 0;
    for (int j = i; j < this.buf_.length; j++)
    {
      int k = (j + this.next_) % this.buf_.length;
      int m = this.buf_[k];
      if (m < 65536)
        localStringBuffer.append((char)m);
      else
        localStringBuffer.append(Integer.toString(m - 65536));
    }
    return localStringBuffer.toString();
  }
}

/* Location:           D:\android\workspaces\eclipse\androidUtils\libs\pinyin4j-2.5.0.jar
 * Qualified Name:     com.hp.hpl.sparta.CharCircBuffer
 * JD-Core Version:    0.6.0
 */